import React, { useState } from 'react';
import { X, UserPlus } from 'lucide-react';
import { useGym } from '../context/GymContext';
import { MembershipPlan } from '../types';

export const NewMemberModal: React.FC = () => {
  const { isNewMemberModalOpen, setIsNewMemberModalOpen, addMember, trainers, formatPrice } = useGym();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [plan, setPlan] = useState<MembershipPlan>('All-Access VIP');
  const [assignedTrainer, setAssignedTrainer] = useState(trainers[0]?.name || 'Alex Rivera');
  const [fitnessGoal, setFitnessGoal] = useState('Strength & Body Recomp');
  const [lockerNumber, setLockerNumber] = useState('');

  if (!isNewMemberModalOpen) return null;

  const planFees: Record<MembershipPlan, number> = {
    'All-Access VIP': 179,
    'CrossFit Pro': 149,
    'Standard Fitness': 79,
    'Yoga & Pilates Studio': 129,
    'Student / Off-Peak': 49,
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addMember({
      name,
      email: email || `${name.toLowerCase().replace(/\s+/g, '')}@gymmember.com`,
      phone: phone || '+1 (555) 890-1234',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      plan,
      status: 'Active',
      monthlyFee: planFees[plan],
      startDate: new Date().toISOString().split('T')[0],
      expirationDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      assignedTrainer,
      lockerNumber: lockerNumber || `L-${Math.floor(Math.random() * 80 + 1)}`,
      fitnessGoal,
      emergencyContact: 'Family Contact (+1 555-400-9988)',
    });

    setIsNewMemberModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 dark:bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white dark:bg-[#121214] border border-zinc-200 dark:border-white/[0.1] rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-fade-in-up">
        {/* Header */}
        <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-black dark:bg-white text-white dark:text-black flex items-center justify-center font-bold">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-zinc-900 dark:text-white">Enroll New Gym Member</h3>
              <p className="text-[11px] text-zinc-500">Contract & Digital Membership Pass Configuration</p>
            </div>
          </div>
          <button
            onClick={() => setIsNewMemberModalOpen(false)}
            className="p-1.5 text-zinc-400 hover:text-zinc-900 dark:hover:text-white rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1">Full Member Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jordan Hayes"
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-all font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="jordan@example.com"
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-all font-medium"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1">Phone Number</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 (555) 234-5678"
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-all font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1">Membership Plan</label>
              <select
                value={plan}
                onChange={(e) => setPlan(e.target.value as MembershipPlan)}
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-colors"
              >
                <option value="All-Access VIP">All-Access VIP ({formatPrice(179)}/mo)</option>
                <option value="CrossFit Pro">CrossFit Pro ({formatPrice(149)}/mo)</option>
                <option value="Standard Fitness">Standard Fitness ({formatPrice(79)}/mo)</option>
                <option value="Yoga & Pilates Studio">Yoga & Pilates ({formatPrice(129)}/mo)</option>
                <option value="Student / Off-Peak">Student / Off-Peak ({formatPrice(49)}/mo)</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1">Assigned Coach</label>
              <select
                value={assignedTrainer}
                onChange={(e) => setAssignedTrainer(e.target.value)}
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-colors"
              >
                {trainers.map((t) => (
                  <option key={t.id} value={t.name}>{t.name} ({t.role})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1">Fitness Goal</label>
              <input
                type="text"
                value={fitnessGoal}
                onChange={(e) => setFitnessGoal(e.target.value)}
                placeholder="e.g. Marathon, Bench 300, Recomp"
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-all font-medium"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1">Locker # (Optional)</label>
              <input
                type="text"
                value={lockerNumber}
                onChange={(e) => setLockerNumber(e.target.value)}
                placeholder="e.g. L-55"
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-all font-medium"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsNewMemberModalOpen(false)}
              className="px-4 py-2 text-xs font-medium text-zinc-500 hover:text-zinc-900 dark:hover:text-white rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-black hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 active:scale-95 text-white dark:text-black text-xs font-bold rounded-xl shadow-md transition-all duration-150"
            >
              Enroll & Issue Pass
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
