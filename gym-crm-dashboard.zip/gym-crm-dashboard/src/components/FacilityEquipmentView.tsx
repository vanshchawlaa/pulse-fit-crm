import React from 'react';
import { Wrench, CheckCircle2, AlertTriangle, XCircle, ShieldCheck } from 'lucide-react';
import { useGym } from '../context/GymContext';

export const FacilityEquipmentView: React.FC = () => {
  const { equipment, updateEquipmentStatus } = useGym();

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'Operational':
        return { color: 'text-zinc-900 dark:text-white bg-zinc-100 dark:bg-zinc-800 border-zinc-300 dark:border-zinc-700 font-semibold', icon: CheckCircle2 };
      case 'Maintenance Needed':
        return { color: 'text-zinc-800 dark:text-zinc-200 bg-zinc-200 dark:bg-zinc-800 border-zinc-400 dark:border-zinc-600', icon: AlertTriangle };
      case 'Under Repair':
        return { color: 'text-zinc-500 bg-zinc-100 dark:bg-zinc-900 border-zinc-300 dark:border-zinc-800 line-through', icon: XCircle };
      default:
        return { color: 'text-zinc-400 bg-zinc-100 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800', icon: CheckCircle2 };
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* Top Banner */}
      <div className="glass-panel p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-zinc-900 dark:text-white flex items-center gap-2">
            <Wrench className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
            <span>Equipment & Facility Maintenance Log</span>
          </h2>
          <p className="text-xs text-zinc-500">
            Cardio decks, Olympic lifting rigs, and recovery plunge suites health monitor.
          </p>
        </div>
        <span className="text-[11px] font-mono text-zinc-800 dark:text-zinc-200 bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-3 py-1.5 rounded-xl">
          98.5% Fleet Uptime Active
        </span>
      </div>

      {/* Equipment Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {equipment.map((eq) => {
          const { color, icon: StatusIcon } = getStatusInfo(eq.status);

          return (
            <div
              key={eq.id}
              className="glass-panel glass-panel-hover rounded-2xl p-5 shadow-sm flex flex-col justify-between group"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <span className="text-[10px] font-mono font-medium text-zinc-400 uppercase tracking-wider block mb-1">
                    {eq.zone} • {eq.category}
                  </span>
                  <h3 className="font-semibold text-sm text-zinc-900 dark:text-white">
                    {eq.name}
                  </h3>
                </div>

                <span className={`flex items-center gap-1.5 text-[11px] font-medium px-2.5 py-0.5 rounded-full border ${color}`}>
                  <StatusIcon className="w-3.5 h-3.5" />
                  <span>{eq.status}</span>
                </span>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-zinc-200 dark:border-zinc-800 text-xs">
                <span className="text-zinc-500 text-[11px]">
                  Last Safety Audit: <strong className="text-zinc-800 dark:text-zinc-200 font-mono">{eq.lastInspected}</strong>
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => updateEquipmentStatus(eq.id, 'Operational')}
                    className="px-2.5 py-1 text-[11px] font-medium bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800 rounded-lg transition-colors"
                  >
                    Operational
                  </button>
                  <button
                    onClick={() => updateEquipmentStatus(eq.id, 'Maintenance Needed')}
                    className="px-2.5 py-1 text-[11px] font-medium bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800 rounded-lg transition-colors"
                  >
                    Flag Service
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
