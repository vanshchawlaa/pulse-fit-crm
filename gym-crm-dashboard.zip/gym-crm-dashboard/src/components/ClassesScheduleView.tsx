import React, { useState } from 'react';
import { 
  CalendarDays, 
  Clock, 
  Users, 
  Award, 
  Plus, 
  CheckCircle,
  MapPin,
  Check
} from 'lucide-react';
import { useGym } from '../context/GymContext';

export const ClassesScheduleView: React.FC = () => {
  const { classes, bookClassSlot, cancelClassSlot } = useGym();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [justBookedId, setJustBookedId] = useState<string | null>(null);

  const categories = ['all', 'HIIT', 'CrossFit', 'Yoga', 'Spin', 'Boxing'];

  const filteredClasses = classes.filter((c) => {
    return selectedCategory === 'all' || c.category === selectedCategory;
  });

  const handleBook = (clsId: string) => {
    bookClassSlot(clsId, 'mem-101');
    setJustBookedId(clsId);
    setTimeout(() => setJustBookedId(null), 1500);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* Top Filter and Info */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-panel p-4 rounded-2xl shadow-sm">
        <div className="flex items-center gap-1.5 overflow-x-auto bg-zinc-100 dark:bg-zinc-900 p-1 rounded-xl border border-zinc-200 dark:border-zinc-800">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`text-xs px-3.5 py-1.5 rounded-lg font-medium transition-all duration-150 capitalize ${
                selectedCategory === cat
                  ? 'bg-zinc-900 dark:bg-white text-white dark:text-black font-semibold shadow-sm'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              {cat === 'all' ? 'All Studios' : cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-800 px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-700 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-zinc-900 dark:bg-white animate-pulse" />
            5 Studios Active Today
          </span>
        </div>
      </div>

      {/* Class Schedule Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredClasses.map((cls) => {
          const isFull = cls.bookedCount >= cls.capacity;
          const isBookedByUser = cls.bookedMembers.includes('mem-101');
          const occupancyPercent = Math.round((cls.bookedCount / cls.capacity) * 100);

          return (
            <div
              key={cls.id}
              className="glass-panel glass-panel-hover rounded-2xl p-5 shadow-sm flex flex-col justify-between group"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-700 uppercase">
                    {cls.category}
                  </span>
                  <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 border border-zinc-200 dark:border-zinc-800">
                    {cls.intensity} Intensity
                  </span>
                </div>

                <h3 className="text-base font-semibold text-zinc-900 dark:text-white tracking-tight mb-2">
                  {cls.name}
                </h3>

                {/* Details */}
                <div className="space-y-1.5 text-xs text-zinc-600 dark:text-zinc-400 mb-5">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-zinc-500" />
                    <span>{cls.time} ({cls.durationMinutes} mins)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-zinc-500" />
                    <span>{cls.room}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-3.5 h-3.5 text-zinc-500" />
                    <span>Coach: <strong className="text-zinc-900 dark:text-zinc-200 font-medium">{cls.trainerName}</strong></span>
                  </div>
                </div>

                {/* Capacity Progress Bar */}
                <div className="space-y-1.5 mb-5 bg-zinc-50 dark:bg-zinc-900/60 p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500 font-medium">Class Capacity</span>
                    <span className="font-mono text-zinc-900 dark:text-white font-semibold">
                      {cls.bookedCount} / {cls.capacity} ({occupancyPercent}%)
                    </span>
                  </div>
                  <div className="w-full bg-zinc-200 dark:bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500 bg-black dark:bg-white"
                      style={{ width: `${occupancyPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div>
                {isBookedByUser ? (
                  <button
                    onClick={() => cancelClassSlot(cls.id, 'mem-101')}
                    className="w-full py-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold rounded-xl border border-zinc-200 dark:border-zinc-800 transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>Cancel Reservation</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleBook(cls.id)}
                    disabled={isFull}
                    className={`w-full py-2.5 text-xs font-semibold rounded-xl transition-all duration-150 flex items-center justify-center gap-2 ${
                      isFull
                        ? 'bg-zinc-100 dark:bg-zinc-900 text-zinc-400 border border-zinc-200 dark:border-zinc-800 cursor-not-allowed'
                        : justBookedId === cls.id
                        ? 'bg-zinc-900 dark:bg-white text-white dark:text-black font-bold'
                        : 'bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black shadow-sm active:scale-95'
                    }`}
                  >
                    {justBookedId === cls.id ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Reserved!</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>{isFull ? 'Class Waitlist Full' : 'Book Spot for Member'}</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
