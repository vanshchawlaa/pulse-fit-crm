import React from 'react';
import { 
  Dumbbell, 
  Users, 
  CalendarDays, 
  Award, 
  Target, 
  Wrench, 
  TrendingUp, 
  UserPlus, 
  QrCode, 
  Settings,
  Zap,
  Send,
  FileSpreadsheet,
  CreditCard,
  ChevronRight
} from 'lucide-react';
import { useGym, ActiveView } from '../context/GymContext';

export const GymSidebar: React.FC = () => {
  const { 
    activeView, 
    setActiveView, 
    setIsCheckInModalOpen, 
    setIsNewMemberModalOpen, 
    members, 
    leads, 
    classes,
    campaigns,
    floorCapacityPercentage,
    todaysCheckInsCount
  } = useGym();

  const expiringCount = members.filter(m => m.status === 'Expiring Soon').length;

  const navItems: { id: ActiveView; label: string; icon: any; badge?: number; alert?: boolean; isNew?: boolean }[] = [
    { id: 'overview', label: 'Operations Hub', icon: Dumbbell },
    { id: 'members', label: 'Members Directory', icon: Users, badge: members.length, alert: expiringCount > 0 },
    { id: 'marketing', label: 'WhatsApp & Email Hub', icon: Send, badge: campaigns.length, isNew: true },
    { id: 'import', label: 'Excel & Data Import', icon: FileSpreadsheet, isNew: true },
    { id: 'classes', label: 'Classes & Timetable', icon: CalendarDays, badge: classes.length },
    { id: 'trainers', label: 'Coaches & PT Staff', icon: Award },
    { id: 'subscriptions', label: 'Subscription Plans', icon: CreditCard, isNew: true },
    { id: 'leads', label: 'Trials & Sales Funnel', icon: Target, badge: leads.length },
    { id: 'facility', label: 'Equipment & Uptime', icon: Wrench },
    { id: 'analytics', label: 'Revenue & Retention', icon: TrendingUp },
  ];

  return (
    <aside className="w-64 border-r border-zinc-200 dark:border-white/[0.08] bg-white dark:bg-black flex flex-col h-screen select-none transition-all duration-200 relative z-20">
      {/* Brand Header */}
      <div className="p-5 border-b border-zinc-200 dark:border-white/[0.08] flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-black dark:bg-white text-white dark:text-black flex items-center justify-center font-bold shadow-sm">
            <Zap className="w-4 h-4 fill-current" />
          </div>
          <div>
            <div className="font-bold text-sm text-zinc-900 dark:text-white tracking-tight flex items-center gap-1.5">
              <span>PULSE</span>
              <span className="font-light text-zinc-500">FIT</span>
              <span className="text-[9px] bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 font-mono px-1.5 py-0.5 rounded-full border border-zinc-300 dark:border-zinc-700">STUDIO</span>
            </div>
            <div className="text-[10px] text-zinc-500 font-medium tracking-wide">Downtown Flagship</div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-3 space-y-1.5">
        <button
          onClick={() => setIsCheckInModalOpen(true)}
          className="w-full group flex items-center justify-center gap-2 bg-black hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 active:scale-[0.98] text-white dark:text-black text-xs font-semibold py-2.5 px-3 rounded-xl shadow-md transition-all duration-200"
        >
          <QrCode className="w-3.5 h-3.5 transition-transform duration-200 group-hover:scale-110" />
          <span>Quick Scan Check-in</span>
        </button>

        <button
          onClick={() => setIsNewMemberModalOpen(true)}
          className="w-full flex items-center justify-center gap-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-900 dark:text-zinc-200 text-xs font-medium py-2 px-3 rounded-xl border border-zinc-300 dark:border-zinc-800 transition-all duration-200"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>+ Enroll Member</span>
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-2 space-y-0.5 overflow-y-auto">
        <div className="text-[10px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest px-3 py-2 font-mono">
          Operations & Growth
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full group flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-zinc-100 dark:bg-white/[0.08] text-zinc-900 dark:text-white font-semibold border border-zinc-300 dark:border-white/10'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-900 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 transition-colors duration-150 ${isActive ? 'text-zinc-900 dark:text-white' : 'text-zinc-400 group-hover:text-zinc-700 dark:group-hover:text-zinc-200'}`} />
                <span>{item.label}</span>
              </div>
              <div className="flex items-center gap-1.5">
                {item.isNew && (
                  <span className="text-[9px] font-mono font-bold px-1 py-0.2 rounded bg-black dark:bg-white text-white dark:text-black">
                    NEW
                  </span>
                )}
                {item.alert && (
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-900 dark:bg-white animate-pulse" title="Expiring soon" />
                )}
                {item.badge !== undefined && !item.isNew && (
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                    isActive 
                      ? 'bg-zinc-200 dark:bg-zinc-800 text-zinc-900 dark:text-white' 
                      : 'bg-zinc-100 dark:bg-zinc-900 text-zinc-500'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </nav>

      {/* Live Floor Capacity Widget */}
      <div className="p-3 border-t border-zinc-200 dark:border-white/[0.08] space-y-2.5">
        <div className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <div className="flex items-center gap-1.5 text-zinc-600 dark:text-zinc-400 text-[11px] font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-zinc-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-zinc-900 dark:bg-white"></span>
              </span>
              <span>Floor Capacity</span>
            </div>
            <span className="font-mono text-[11px] text-zinc-900 dark:text-white font-semibold">
              {floorCapacityPercentage}%
            </span>
          </div>

          <div className="w-full bg-zinc-200 dark:bg-zinc-800 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-black dark:bg-white h-1.5 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${floorCapacityPercentage}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[10px] text-zinc-500 mt-2 font-mono">
            <span>Turnstiles: Ready</span>
            <span>{todaysCheckInsCount} checked in</span>
          </div>
        </div>

        {/* Manager User Info */}
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-900 dark:text-white flex items-center justify-center text-[10px] font-bold">
              PF
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-semibold text-zinc-900 dark:text-white truncate">Club Ops</div>
              <div className="text-[10px] text-zinc-500">Terminal 01</div>
            </div>
          </div>
          <button 
            onClick={() => setActiveView('settings')}
            className="p-1.5 text-zinc-500 hover:text-zinc-900 dark:hover:text-white rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900 transition-colors"
            title="Club Settings"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
