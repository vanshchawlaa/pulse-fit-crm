import React from 'react';
import { 
  X, 
  Dumbbell, 
  Phone, 
  Mail, 
  Calendar, 
  User, 
  Trash2, 
  CheckCircle, 
  AlertTriangle,
  QrCode,
  Shield,
  MessageSquare,
  Send
} from 'lucide-react';
import { useGym } from '../context/GymContext';
import { Member, MembershipStatus, MembershipPlan } from '../types';

export const MemberDetailDrawer: React.FC = () => {
  const { selectedMember, setSelectedMember, updateMember, deleteMember, checkInMember, setActiveView, formatPrice } = useGym();

  if (!selectedMember) return null;

  const handleStatusChange = (status: MembershipStatus) => {
    updateMember(selectedMember.id, { status });
  };

  const handlePlanChange = (plan: MembershipPlan) => {
    const fees: Record<MembershipPlan, number> = {
      'All-Access VIP': 179,
      'CrossFit Pro': 149,
      'Standard Fitness': 79,
      'Yoga & Pilates Studio': 129,
      'Student / Off-Peak': 49,
    };
    updateMember(selectedMember.id, { plan, monthlyFee: fees[plan] });
  };

  const phoneDigits = selectedMember.phone.replace(/[^0-9]/g, '');
  const directWhatsAppUrl = `https://api.whatsapp.com/send?phone=${phoneDigits}&text=${encodeURIComponent(
    `Hi ${selectedMember.name}! Checking in from PULSE FIT Flagship Concierge regarding your ${selectedMember.plan} membership.`
  )}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 dark:bg-black/80 backdrop-blur-md flex items-center justify-end animate-fade-in">
      <div className="bg-white dark:bg-[#121214] border-l border-zinc-200 dark:border-white/[0.1] w-full max-w-lg h-full shadow-2xl flex flex-col animate-slide-in-right">
        {/* Header */}
        <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white border border-zinc-300 dark:border-zinc-700 uppercase">
              Gym Member Pass
            </span>
            <span className="text-xs text-zinc-500 font-mono">#{selectedMember.id}</span>
          </div>
          <button
            onClick={() => setSelectedMember(null)}
            className="p-1.5 text-zinc-400 hover:text-zinc-900 dark:hover:text-white rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Member Profile Banner */}
          <div className="flex items-center gap-4 bg-zinc-50 dark:bg-zinc-900/60 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800">
            <img
              src={selectedMember.avatar}
              alt={selectedMember.name}
              className="w-16 h-16 rounded-2xl object-cover ring-1 ring-zinc-300 dark:ring-zinc-700"
            />
            <div className="flex-1 min-w-0">
              <h2 className="text-base font-bold text-zinc-900 dark:text-white truncate">{selectedMember.name}</h2>
              <div className="text-xs text-zinc-600 dark:text-zinc-400 font-medium">{selectedMember.plan}</div>
              <div className="text-[11px] text-zinc-500 mt-1">
                Locker: <strong className="text-zinc-900 dark:text-zinc-200 font-mono font-normal">{selectedMember.lockerNumber || 'Unassigned'}</strong>
              </div>
            </div>
            <div className="flex flex-col gap-1.5 shrink-0">
              <button
                onClick={() => checkInMember(selectedMember.id)}
                className="px-3 py-1.5 bg-zinc-900 dark:bg-white text-white dark:text-black text-xs font-semibold rounded-xl shadow-sm transition-all active:scale-95"
              >
                Scan In
              </button>
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1 transition-colors"
                title="Message on WhatsApp"
              >
                <MessageSquare className="w-3 h-3" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Membership Status Switcher */}
          <div className="space-y-2">
            <label className="text-[11px] font-mono text-zinc-500 uppercase tracking-wider block">
              Contract Status
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Active', 'Frozen', 'Expiring Soon'] as MembershipStatus[]).map((st) => (
                <button
                  key={st}
                  onClick={() => handleStatusChange(st)}
                  className={`py-2 px-2 text-xs font-medium rounded-xl transition-all duration-150 ${
                    selectedMember.status === st
                      ? 'bg-zinc-900 dark:bg-white text-white dark:text-black font-semibold shadow-sm'
                      : 'bg-zinc-50 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 border border-zinc-200 dark:border-zinc-800 hover:text-zinc-900 dark:hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* Membership Plan Tier */}
          <div className="space-y-2">
            <label className="text-[11px] font-mono text-zinc-500 uppercase tracking-wider block">
              Change Membership Tier
            </label>
            <select
              value={selectedMember.plan}
              onChange={(e) => handlePlanChange(e.target.value as MembershipPlan)}
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs rounded-xl px-3.5 py-2.5 text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-colors font-medium"
            >
              <option value="All-Access VIP">All-Access VIP ({formatPrice(179)}/mo)</option>
              <option value="CrossFit Pro">CrossFit Pro ({formatPrice(149)}/mo)</option>
              <option value="Standard Fitness">Standard Fitness ({formatPrice(79)}/mo)</option>
              <option value="Yoga & Pilates Studio">Yoga & Pilates ({formatPrice(129)}/mo)</option>
              <option value="Student / Off-Peak">Student / Off-Peak ({formatPrice(49)}/mo)</option>
            </select>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-zinc-50 dark:bg-zinc-900/60 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block mb-1">Lifetime Workouts</span>
              <div className="text-2xl font-bold text-zinc-900 dark:text-white font-mono flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-zinc-500" />
                {selectedMember.totalCheckIns}
              </div>
            </div>

            <div className="bg-zinc-50 dark:bg-zinc-900/60 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block mb-1">Contract Expiration</span>
              <div className="text-xs font-semibold text-zinc-900 dark:text-white font-mono mt-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-zinc-500" />
                {selectedMember.expirationDate}
              </div>
            </div>
          </div>

          {/* Fitness Goal & Coach */}
          <div className="bg-zinc-50 dark:bg-zinc-900/60 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-3 text-xs">
            <div>
              <span className="text-[10px] uppercase font-mono text-zinc-500 block mb-1">Primary Fitness Goal</span>
              <p className="text-zinc-900 dark:text-white font-medium">{selectedMember.fitnessGoal || 'General Strength & Health'}</p>
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-zinc-500 block mb-1">Assigned Personal Coach</span>
              <p className="text-zinc-900 dark:text-white font-medium">{selectedMember.assignedTrainer || 'None Assigned'}</p>
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-zinc-500 block mb-1">Emergency Contact</span>
              <p className="text-zinc-600 dark:text-zinc-400 font-mono">{selectedMember.emergencyContact || 'Not Listed'}</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
          <button
            onClick={() => {
              deleteMember(selectedMember.id);
            }}
            className="flex items-center gap-1.5 text-xs font-medium text-rose-500 hover:text-rose-600 px-3 py-2 rounded-xl hover:bg-rose-500/10 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Cancel Membership</span>
          </button>

          <button
            onClick={() => setSelectedMember(null)}
            className="px-5 py-2 bg-zinc-900 dark:bg-white text-white dark:text-black text-xs font-semibold rounded-xl transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
