import React, { useState } from 'react';
import { 
  Send, 
  MessageSquare, 
  Mail, 
  Users, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  Smartphone, 
  Laptop, 
  ArrowRight,
  ExternalLink,
  Copy,
  Check,
  Flame,
  FileText
} from 'lucide-react';
import { useGym } from '../context/GymContext';
import { CampaignChannel, CampaignAudience, MarketingTemplate } from '../types';

export const MarketingHubView: React.FC = () => {
  const { 
    members, 
    leads, 
    campaigns, 
    templates, 
    sendCampaign 
  } = useGym();

  const [channel, setChannel] = useState<CampaignChannel>('whatsapp');
  const [targetAudience, setTargetAudience] = useState<CampaignAudience>('expiring');
  const [title, setTitle] = useState('48-Hour Renewal Special 20% Off');
  const [subject, setSubject] = useState('Exclusive: 20% Off Your PULSE FIT Annual Pass');
  const [message, setMessage] = useState(
    'Hey {name}! 🏋️ Your PULSE FIT pass expires on {expiry_date}. Renew today to lock in 20% off your monthly dues for life. Reply YES to confirm or click: https://pulsefit.club/renew'
  );
  const [copiedLink, setCopiedLink] = useState(false);
  const [justSent, setJustSent] = useState(false);

  // Calculate target audience members
  const targetMembers = React.useMemo(() => {
    switch (targetAudience) {
      case 'all':
        return members;
      case 'expiring':
        return members.filter((m) => m.status === 'Expiring Soon');
      case 'vip':
        return members.filter((m) => m.plan === 'All-Access VIP');
      case 'inactive':
        return members.filter((m) => m.status === 'Frozen' || m.status === 'Cancelled');
      case 'leads':
        return leads.map((l) => ({
          id: l.id,
          name: l.name,
          phone: l.phone,
          email: l.email,
          plan: l.interest as any,
          status: 'Active' as const,
          expirationDate: 'Trial',
          monthlyFee: 0,
          startDate: l.createdAt,
          totalCheckIns: 0,
          lastVisit: 'None',
          avatar: '',
        }));
      default:
        return members;
    }
  }, [targetAudience, members, leads]);

  // Preview personalized sample with first member
  const sampleMember = targetMembers[0] || {
    name: 'Marcus Sterling',
    plan: 'All-Access VIP',
    expirationDate: '2026-12-31',
    phone: '+1 (555) 234-5678',
  };

  const previewMessage = message
    .replace(/{name}/g, sampleMember.name)
    .replace(/{plan}/g, sampleMember.plan)
    .replace(/{expiry_date}/g, sampleMember.expirationDate)
    .replace(/{total_workouts}/g, '142');

  const handleApplyTemplate = (tmpl: MarketingTemplate) => {
    setChannel(tmpl.channel);
    if (tmpl.subject) setSubject(tmpl.subject);
    setMessage(tmpl.content);
    setTitle(tmpl.title);
  };

  const handleSendCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    sendCampaign({
      title: title || `${channel === 'whatsapp' ? 'WhatsApp' : 'Email'} Broadcast`,
      channel,
      targetAudience,
      subject: channel === 'email' ? subject : undefined,
      message,
      recipientCount: Math.max(1, targetMembers.length),
    });

    setJustSent(true);
    setTimeout(() => setJustSent(false), 2500);
  };

  // Direct WhatsApp Web dispatch link
  const samplePhoneDigits = sampleMember.phone.replace(/[^0-9]/g, '');
  const directWhatsAppUrl = `https://api.whatsapp.com/send?phone=${samplePhoneDigits}&text=${encodeURIComponent(previewMessage)}`;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* Top Banner */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-700 font-semibold">
              Omnichannel Marketing
            </span>
            <span className="text-xs text-zinc-500 font-mono">WhatsApp API & Email Engine</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white">
            Member Retention & Broadcast Campaigns
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
            Dispatch personalized promotions, expiring membership renewals, and free trial workout passes directly to members.
          </p>
        </div>

        {/* Quick Audience Stats */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs text-zinc-500">Audience Scope</div>
            <div className="text-sm font-bold font-mono text-zinc-900 dark:text-white">
              {targetMembers.length} Recipients
            </div>
          </div>
          <div className="h-8 w-px bg-zinc-200 dark:bg-zinc-800" />
          <div className="text-right">
            <div className="text-xs text-zinc-500">Avg Delivery</div>
            <div className="text-sm font-bold font-mono text-zinc-900 dark:text-white">
              98.4%
            </div>
          </div>
        </div>
      </div>

      {/* Main Campaign Builder Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Campaign Config */}
        <div className="lg:col-span-7 space-y-5">
          <form onSubmit={handleSendCampaign} className="glass-panel p-5 rounded-2xl space-y-4">
            {/* Channel Switcher */}
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider block mb-1.5">
                1. Select Marketing Channel
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setChannel('whatsapp')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all duration-200 ${
                    channel === 'whatsapp'
                      ? 'bg-zinc-900 dark:bg-white text-white dark:text-black border-transparent shadow-md'
                      : 'bg-zinc-100 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-800 hover:text-zinc-900 dark:hover:text-white'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp Broadcast</span>
                </button>

                <button
                  type="button"
                  onClick={() => setChannel('email')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all duration-200 ${
                    channel === 'email'
                      ? 'bg-zinc-900 dark:bg-white text-white dark:text-black border-transparent shadow-md'
                      : 'bg-zinc-100 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-800 hover:text-zinc-900 dark:hover:text-white'
                  }`}
                >
                  <Mail className="w-4 h-4" />
                  <span>Email Campaign Blast</span>
                </button>
              </div>
            </div>

            {/* Target Audience */}
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider block mb-1.5">
                2. Target Recipient Segment
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'expiring', label: 'Expiring Soon (14D)', count: members.filter(m => m.status === 'Expiring Soon').length },
                  { id: 'all', label: 'All Active Members', count: members.length },
                  { id: 'leads', label: 'Free Trial Guests', count: leads.length },
                  { id: 'vip', label: 'VIP Passholders', count: members.filter(m => m.plan === 'All-Access VIP').length },
                  { id: 'inactive', label: 'Frozen / Inactive', count: members.filter(m => m.status === 'Frozen' || m.status === 'Cancelled').length },
                ].map((aud) => (
                  <button
                    key={aud.id}
                    type="button"
                    onClick={() => setTargetAudience(aud.id as CampaignAudience)}
                    className={`py-2 px-2.5 rounded-xl text-left border text-xs transition-all duration-200 ${
                      targetAudience === aud.id
                        ? 'bg-zinc-900 dark:bg-white text-white dark:text-black border-transparent font-semibold shadow-sm'
                        : 'bg-zinc-50 dark:bg-zinc-900/60 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 dark:hover:border-zinc-600'
                    }`}
                  >
                    <div className="truncate">{aud.label}</div>
                    <div className="text-[10px] opacity-75 font-mono">{aud.count} members</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Campaign Title */}
            <div>
              <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider block mb-1">
                Campaign Name
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. 20% Off Renewal Flash Sale"
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500"
              />
            </div>

            {/* Subject (for Email only) */}
            {channel === 'email' && (
              <div>
                <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider block mb-1">
                  Email Subject Line
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Subject line..."
                  className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 font-medium"
                />
              </div>
            )}

            {/* Message Body */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 uppercase tracking-wider">
                  Message Content & Merge Tags
                </label>
                <span className="text-[10px] text-zinc-500 font-mono">
                  Tags: {'{name}'}, {'{plan}'}, {'{expiry_date}'}
                </span>
              </div>
              <textarea
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 font-mono leading-relaxed"
              />
            </div>

            {/* Quick Templates Shelf */}
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                Fast Template Presets:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {templates
                  .filter((t) => t.channel === channel)
                  .map((tmpl) => (
                    <button
                      key={tmpl.id}
                      type="button"
                      onClick={() => handleApplyTemplate(tmpl)}
                      className="p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 dark:hover:border-zinc-600 bg-zinc-50 dark:bg-zinc-900/40 text-left text-xs transition-colors group"
                    >
                      <div className="font-semibold text-zinc-900 dark:text-white truncate flex items-center justify-between">
                        <span>{tmpl.title}</span>
                        <span className="text-[9px] font-mono bg-zinc-200 dark:bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-600 dark:text-zinc-400">
                          {tmpl.category}
                        </span>
                      </div>
                      <div className="text-[10px] text-zinc-500 line-clamp-1 mt-0.5">
                        {tmpl.content}
                      </div>
                    </button>
                  ))}
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3">
              {channel === 'whatsapp' ? (
                <a
                  href={directWhatsAppUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl flex items-center gap-1.5 transition-colors shadow-sm"
                  title="Test Live in WhatsApp Web"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Test in WhatsApp Web</span>
                </a>
              ) : (
                <div className="text-xs text-zinc-500 font-mono">
                  Audience: {targetMembers.length} verified emails
                </div>
              )}

              <button
                type="submit"
                className="px-5 py-2.5 bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black font-semibold text-xs rounded-xl shadow-lg flex items-center gap-2 active:scale-95 transition-all duration-200"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{justSent ? 'Campaign Dispatched!' : `Broadcast to ${targetMembers.length} Athletes`}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Preview Device Simulator */}
        <div className="lg:col-span-5 space-y-5">
          <div className="glass-panel p-5 rounded-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800 mb-4">
              <div className="flex items-center gap-2">
                {channel === 'whatsapp' ? (
                  <Smartphone className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
                ) : (
                  <Laptop className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
                )}
                <span className="text-xs font-semibold text-zinc-900 dark:text-white">
                  Live {channel === 'whatsapp' ? 'WhatsApp Device' : 'Email Client'} Preview
                </span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500">
                Sample: {sampleMember.name}
              </span>
            </div>

            {/* Simulated Device Screen */}
            {channel === 'whatsapp' ? (
              <div className="bg-[#0b141a] text-zinc-100 rounded-2xl p-4 shadow-xl border border-zinc-800 space-y-3 font-sans">
                {/* Simulated Header */}
                <div className="flex items-center gap-2 pb-2 border-b border-zinc-800 text-xs">
                  <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">
                    PF
                  </div>
                  <div>
                    <div className="font-semibold text-white">PULSE FIT Flagship</div>
                    <div className="text-[10px] text-zinc-400">Official Club Broadcast</div>
                  </div>
                </div>

                {/* Simulated Message Bubble */}
                <div className="bg-[#005c4b] text-white text-xs p-3.5 rounded-2xl rounded-tl-sm shadow-sm leading-relaxed max-w-[90%] whitespace-pre-wrap">
                  {previewMessage}
                  <div className="text-[9px] text-emerald-200 text-right mt-1.5 font-mono">
                    11:42 AM • ✓✓
                  </div>
                </div>

                <div className="text-[10px] text-zinc-500 text-center font-mono">
                  Recipient Phone: {sampleMember.phone}
                </div>
              </div>
            ) : (
              <div className="bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 rounded-2xl p-4 shadow-xl border border-zinc-200 dark:border-zinc-800 space-y-3 font-sans text-xs">
                {/* Email Envelope Header */}
                <div className="space-y-1 pb-2 border-b border-zinc-200 dark:border-zinc-800 text-[11px]">
                  <div className="text-zinc-500">
                    <strong className="text-zinc-800 dark:text-zinc-200">From:</strong> PULSE FIT &lt;concierge@pulsefit.club&gt;
                  </div>
                  <div className="text-zinc-500">
                    <strong className="text-zinc-800 dark:text-zinc-200">To:</strong> {sampleMember.name} &lt;{sampleMember.name.toLowerCase().replace(/\s+/g, '')}@gymmember.com&gt;
                  </div>
                  <div className="text-zinc-900 dark:text-white font-semibold pt-1">
                    {subject}
                  </div>
                </div>

                {/* Email Content Body */}
                <div className="bg-white dark:bg-zinc-900 p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 whitespace-pre-wrap leading-relaxed text-zinc-800 dark:text-zinc-200 text-xs">
                  {previewMessage}
                </div>
              </div>
            )}
          </div>

          {/* Quick Direct Member WhatsApp Dispatch */}
          <div className="glass-panel p-5 rounded-2xl space-y-3">
            <h3 className="text-xs font-semibold text-zinc-900 dark:text-white flex items-center justify-between">
              <span>Quick 1-on-1 Member WhatsApp</span>
              <span className="text-[10px] font-mono text-zinc-500">Expiring Members</span>
            </h3>

            <div className="space-y-2">
              {members.filter(m => m.status === 'Expiring Soon').slice(0, 3).map((m) => {
                const phoneDigits = m.phone.replace(/[^0-9]/g, '');
                const text = `Hi ${m.name}! ⚡ Your ${m.plan} pass at PULSE FIT is expiring soon. Would you like to renew with 20% off this week?`;
                const directUrl = `https://api.whatsapp.com/send?phone=${phoneDigits}&text=${encodeURIComponent(text)}`;

                return (
                  <div key={m.id} className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs">
                    <div>
                      <div className="font-semibold text-zinc-900 dark:text-white">{m.name}</div>
                      <div className="text-[10px] text-zinc-500">{m.plan} • {m.phone}</div>
                    </div>
                    <a
                      href={directUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold text-[11px] flex items-center gap-1 transition-colors"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Campaign Log & Past Dispatches */}
      <div className="glass-panel rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 dark:text-white">
              Recent Campaign Dispatches & Deliveries
            </h3>
            <p className="text-xs text-zinc-500">
              Audit logs of WhatsApp messages and automated email blasts
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700">
            {campaigns.length} Recorded Campaigns
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[10px] font-mono uppercase text-zinc-500">
                <th className="py-2.5 px-3">Campaign</th>
                <th className="py-2.5 px-3">Channel</th>
                <th className="py-2.5 px-3">Segment</th>
                <th className="py-2.5 px-3">Audience Size</th>
                <th className="py-2.5 px-3">Delivered</th>
                <th className="py-2.5 px-3">Open Rate</th>
                <th className="py-2.5 px-3">Sent Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/60">
              {campaigns.map((cmp) => (
                <tr key={cmp.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/40 transition-colors">
                  <td className="py-3 px-3 font-semibold text-zinc-900 dark:text-white">
                    {cmp.title}
                  </td>
                  <td className="py-3 px-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium border ${
                      cmp.channel === 'whatsapp'
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/25'
                        : 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/25'
                    }`}>
                      {cmp.channel === 'whatsapp' ? <MessageSquare className="w-3 h-3" /> : <Mail className="w-3 h-3" />}
                      <span>{cmp.channel === 'whatsapp' ? 'WhatsApp' : 'Email'}</span>
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono text-zinc-600 dark:text-zinc-400 uppercase text-[10px]">
                    {cmp.targetAudience}
                  </td>
                  <td className="py-3 px-3 font-mono text-zinc-900 dark:text-white">
                    {cmp.recipientCount}
                  </td>
                  <td className="py-3 px-3 font-mono text-emerald-600 dark:text-emerald-400">
                    {cmp.deliveredCount} (100%)
                  </td>
                  <td className="py-3 px-3 font-mono text-zinc-900 dark:text-white">
                    {cmp.openRate}%
                  </td>
                  <td className="py-3 px-3 text-zinc-500 font-mono text-[11px]">
                    {cmp.sentAt}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
