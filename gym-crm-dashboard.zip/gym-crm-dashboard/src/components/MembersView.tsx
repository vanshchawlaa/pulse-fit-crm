import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  UserPlus, 
  Trash2, 
  Phone, 
  Mail, 
  Award, 
  Calendar,
  CheckCircle,
  Clock,
  Dumbbell,
  FileSpreadsheet,
  Send,
  Check
} from 'lucide-react';
import { useGym } from '../context/GymContext';
import { Member, MembershipPlan, MembershipStatus } from '../types';

export const MembersView: React.FC = () => {
  const { 
    members, 
    searchQuery, 
    deleteMember, 
    setSelectedMember, 
    setIsNewMemberModalOpen,
    checkInMember,
    setActiveView,
    formatPrice 
  } = useGym();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [planFilter, setPlanFilter] = useState<string>('all');
  const [justCheckedInId, setJustCheckedInId] = useState<string | null>(null);

  const filteredMembers = members.filter((m) => {
    const matchesSearch = 
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.phone.includes(searchQuery) ||
      (m.lockerNumber && m.lockerNumber.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'all' || m.status === statusFilter;
    const matchesPlan = planFilter === 'all' || m.plan === planFilter;

    return matchesSearch && matchesStatus && matchesPlan;
  });

  const getStatusBadge = (status: MembershipStatus) => {
    switch (status) {
      case 'Active':
        return 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white border-zinc-300 dark:border-zinc-700';
      case 'Expiring Soon':
        return 'bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border-zinc-400 dark:border-zinc-600';
      case 'Frozen':
        return 'bg-zinc-100 dark:bg-zinc-900 text-zinc-500 border-zinc-200 dark:border-zinc-800';
      case 'Cancelled':
        return 'bg-zinc-100 dark:bg-zinc-900 text-zinc-400 line-through border-zinc-200 dark:border-zinc-800';
    }
  };

  const handleQuickCheckIn = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    checkInMember(id);
    setJustCheckedInId(id);
    setTimeout(() => {
      setJustCheckedInId(null);
    }, 1500);
  };

  return (
    <div className="p-6 space-y-5 max-w-7xl mx-auto animate-fade-in">
      {/* Top Filter and Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-panel p-4 rounded-2xl shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          {/* Status Filter Pills */}
          <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-xl border border-zinc-200 dark:border-zinc-800">
            {['all', 'Active', 'Expiring Soon', 'Frozen'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all duration-150 ${
                  statusFilter === st
                    ? 'bg-zinc-900 dark:bg-white text-white dark:text-black font-semibold shadow-sm'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                {st === 'all' ? `All (${members.length})` : st}
              </button>
            ))}
          </div>

          {/* Plan Dropdown */}
          <select
            value={planFilter}
            onChange={(e) => setPlanFilter(e.target.value)}
            className="bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs rounded-xl px-3 py-2 text-zinc-800 dark:text-zinc-200 outline-none focus:border-zinc-500 transition-colors"
          >
            <option value="all">All Membership Tiers</option>
            <option value="All-Access VIP">All-Access VIP ($179)</option>
            <option value="CrossFit Pro">CrossFit Pro ($149)</option>
            <option value="Standard Fitness">Standard Fitness ($79)</option>
            <option value="Yoga & Pilates Studio">Yoga & Pilates ($129)</option>
            <option value="Student / Off-Peak">Student / Off-Peak ($49)</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          {/* Excel Import Shortcut */}
          <button
            onClick={() => setActiveView('import')}
            className="flex items-center gap-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 text-xs font-semibold px-3.5 py-2 rounded-xl border border-zinc-300 dark:border-zinc-800 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Import Excel</span>
          </button>

          {/* Marketing Broadcast Shortcut */}
          <button
            onClick={() => setActiveView('marketing')}
            className="flex items-center gap-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 text-xs font-semibold px-3.5 py-2 rounded-xl border border-zinc-300 dark:border-zinc-800 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Campaign</span>
          </button>

          {/* Enroll Member Button */}
          <button
            onClick={() => setIsNewMemberModalOpen(true)}
            className="flex items-center gap-2 bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 active:scale-95 text-white dark:text-black text-xs font-bold px-4 py-2 rounded-xl shadow-md transition-all duration-150"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>+ Enroll Member</span>
          </button>
        </div>
      </div>

      {/* Members Directory Table */}
      <div className="glass-panel rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/40 text-[10px] font-mono text-zinc-500 uppercase tracking-wider">
                <th className="py-3.5 px-4 font-mono">Member Profile</th>
                <th className="py-3.5 px-4 font-mono">Tier & Rate</th>
                <th className="py-3.5 px-4 font-mono">Status</th>
                <th className="py-3.5 px-4 font-mono">Attendance</th>
                <th className="py-3.5 px-4 font-mono">Assigned Coach</th>
                <th className="py-3.5 px-4 font-mono">Renewal Date</th>
                <th className="py-3.5 px-4 font-mono text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/60 text-xs">
              {filteredMembers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-zinc-500">
                    No members match your current filters
                  </td>
                </tr>
              ) : (
                filteredMembers.map((member) => (
                  <tr
                    key={member.id}
                    onClick={() => setSelectedMember(member)}
                    className="group hover:bg-zinc-50 dark:hover:bg-zinc-900/50 cursor-pointer transition-colors duration-150"
                  >
                    {/* Member Info */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img
                            src={member.avatar}
                            alt={member.name}
                            className="w-9 h-9 rounded-full object-cover ring-1 ring-zinc-300 dark:ring-zinc-700"
                          />
                          <span className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full border border-white dark:border-black ${
                            member.status === 'Active' ? 'bg-zinc-900 dark:bg-white' : 'bg-zinc-400'
                          }`} />
                        </div>
                        <div>
                          <div className="font-semibold text-zinc-900 dark:text-white flex items-center gap-2">
                            <span>{member.name}</span>
                            {member.lockerNumber && (
                              <span className="text-[9px] font-mono bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 px-1.5 py-0.5 rounded border border-zinc-200 dark:border-zinc-700">
                                Locker {member.lockerNumber}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-zinc-500 mt-0.5">
                            {member.phone} • {member.email}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Plan */}
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-zinc-900 dark:text-zinc-200">
                        {member.plan}
                      </div>
                      <div className="text-[11px] font-mono text-zinc-600 dark:text-zinc-400">
                        {formatPrice(member.monthlyFee)}/mo
                      </div>
                    </td>

                    {/* Status Badge */}
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-medium border ${getStatusBadge(member.status)}`}>
                        {member.status}
                      </span>
                    </td>

                    {/* Check Ins */}
                    <td className="py-3.5 px-4">
                      <div className="font-medium font-mono text-zinc-900 dark:text-white flex items-center gap-1.5">
                        <Dumbbell className="w-3.5 h-3.5 text-zinc-500" />
                        {member.totalCheckIns} visits
                      </div>
                      <div className="text-[10px] text-zinc-400 mt-0.5">
                        Last: {member.lastVisit}
                      </div>
                    </td>

                    {/* Trainer */}
                    <td className="py-3.5 px-4 text-zinc-600 dark:text-zinc-400">
                      {member.assignedTrainer ? (
                        <span className="font-medium text-zinc-800 dark:text-zinc-200">
                          {member.assignedTrainer}
                        </span>
                      ) : (
                        <span className="italic text-zinc-400">Self-guided</span>
                      )}
                    </td>

                    {/* Expiration */}
                    <td className="py-3.5 px-4 font-mono text-zinc-500 text-[11px]">
                      {member.expirationDate}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={(e) => handleQuickCheckIn(e, member.id)}
                          className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-all duration-150 flex items-center gap-1 ${
                            justCheckedInId === member.id
                              ? 'bg-zinc-900 dark:bg-white text-white dark:text-black font-bold'
                              : 'bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800'
                          }`}
                          title="Quick Check-in"
                        >
                          {justCheckedInId === member.id ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Done!</span>
                            </>
                          ) : (
                            <span>Check-in</span>
                          )}
                        </button>
                        <button
                          onClick={() => deleteMember(member.id)}
                          className="p-1.5 text-zinc-400 hover:text-rose-500 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900 transition-colors"
                          title="Delete Member"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
