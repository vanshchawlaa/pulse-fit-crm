import React, { useState } from 'react';
import { 
  Target, 
  Phone, 
  Mail, 
  Calendar, 
  Plus, 
  ArrowRight, 
  ArrowLeft, 
  Trash2, 
  CheckCircle,
  MessageSquare
} from 'lucide-react';
import { useGym } from '../context/GymContext';
import { Lead, LeadStage } from '../types';

const STAGES: { id: LeadStage; name: string }[] = [
  { id: 'inquiry', name: 'New Inquiries' },
  { id: 'trial_booked', name: 'Trial Scheduled' },
  { id: 'trial_attended', name: 'Attended Workout' },
  { id: 'membership_pitch', name: 'Contract Sent' },
  { id: 'converted', name: 'Joined Member' },
];

export const LeadsPipelineView: React.FC = () => {
  const { leads, updateLeadStage, addLead, deleteLead, trainers } = useGym();

  const [isAddingLead, setIsAddingLead] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [interest, setInterest] = useState('All-Access VIP');
  const [assignedStaff, setAssignedStaff] = useState('Alex Rivera');
  const [source, setSource] = useState<'Instagram' | 'Walk-in' | 'Google Search' | 'Member Referral' | 'Corporate'>('Instagram');

  const handleCreateLead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    addLead({
      name,
      phone: phone || '+1 (555) 000-1122',
      email: email || `${name.toLowerCase().replace(/\s+/g, '')}@example.com`,
      interest,
      source,
      stage: 'inquiry',
      assignedStaff,
    });
    setName('');
    setPhone('');
    setEmail('');
    setIsAddingLead(false);
  };

  return (
    <div className="p-6 h-full flex flex-col space-y-4 animate-fade-in">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-panel p-4 rounded-2xl shadow-sm">
        <div>
          <h2 className="text-base font-semibold text-zinc-900 dark:text-white flex items-center gap-2">
            <Target className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
            <span>Trial & Membership Sales Pipeline</span>
          </h2>
          <p className="text-xs text-zinc-500">
            Convert prospective trial guests into full annual memberships.
          </p>
        </div>

        <button
          onClick={() => setIsAddingLead(!isAddingLead)}
          className="flex items-center gap-1.5 bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black text-xs font-semibold px-4 py-2 rounded-xl shadow-sm active:scale-95 transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>+ Add Guest Lead</span>
        </button>
      </div>

      {/* Add Lead Form Tray */}
      {isAddingLead && (
        <form onSubmit={handleCreateLead} className="glass-panel rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 animate-fade-in">
          <div>
            <label className="text-[11px] font-medium text-zinc-700 dark:text-zinc-300 block mb-1">Guest Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jake Morrison"
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500"
            />
          </div>
          <div>
            <label className="text-[11px] font-medium text-zinc-700 dark:text-zinc-300 block mb-1">Phone Number</label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+1 (555) 345-0000"
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500"
            />
          </div>
          <div>
            <label className="text-[11px] font-medium text-zinc-700 dark:text-zinc-300 block mb-1">Target Interest</label>
            <input
              type="text"
              value={interest}
              onChange={(e) => setInterest(e.target.value)}
              placeholder="CrossFit, Personal Training"
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500"
            />
          </div>
          <div>
            <label className="text-[11px] font-medium text-zinc-700 dark:text-zinc-300 block mb-1">Assigned Coach</label>
            <select
              value={assignedStaff}
              onChange={(e) => setAssignedStaff(e.target.value)}
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500"
            >
              {trainers.map((t) => (
                <option key={t.id} value={t.name}>{t.name}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end gap-2">
            <button
              type="submit"
              className="flex-1 py-1.5 bg-zinc-900 dark:bg-white text-white dark:text-black text-xs font-semibold rounded-xl"
            >
              Save Lead
            </button>
            <button
              type="button"
              onClick={() => setIsAddingLead(false)}
              className="py-1.5 px-3 bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs rounded-xl"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Kanban Board */}
      <div className="flex-1 overflow-x-auto pb-4">
        <div className="flex items-start gap-4 min-w-[1100px] h-full">
          {STAGES.map((stage, idx) => {
            const stageLeads = leads.filter((l) => l.stage === stage.id);

            return (
              <div
                key={stage.id}
                className="w-72 flex-shrink-0 glass-panel rounded-2xl flex flex-col max-h-[calc(100vh-210px)]"
              >
                {/* Stage Header */}
                <div className="p-3.5 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-zinc-900 dark:bg-white" />
                    <h3 className="text-xs font-semibold text-zinc-900 dark:text-white">{stage.name}</h3>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500 bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded-full border border-zinc-200 dark:border-zinc-700">
                    {stageLeads.length}
                  </span>
                </div>

                {/* Cards */}
                <div className="p-3 space-y-2.5 overflow-y-auto flex-1">
                  {stageLeads.length === 0 ? (
                    <div className="py-8 text-center text-xs text-zinc-400 border border-dashed border-zinc-200 dark:border-zinc-800 rounded-xl">
                      Empty stage
                    </div>
                  ) : (
                    stageLeads.map((lead) => {
                      const phoneDigits = lead.phone.replace(/[^0-9]/g, '');
                      const whatsappText = `Hi ${lead.name}! 🏋️ Welcome to PULSE FIT. Would you like to confirm your workout trial slot this week?`;
                      const waUrl = `https://api.whatsapp.com/send?phone=${phoneDigits}&text=${encodeURIComponent(whatsappText)}`;

                      return (
                        <div
                          key={lead.id}
                          className="bg-zinc-50 dark:bg-zinc-900/50 hover:bg-zinc-100 dark:hover:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3.5 shadow-sm transition-all duration-150 group"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="text-xs font-semibold text-zinc-900 dark:text-white">
                              {lead.name}
                            </h4>
                            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300">
                              {lead.source}
                            </span>
                          </div>

                          <div className="text-[11px] text-zinc-500 space-y-1 mb-3">
                            <div className="flex items-center justify-between">
                              <span className="flex items-center gap-1.5">
                                <Phone className="w-3 h-3 text-zinc-400" />
                                <span>{lead.phone}</span>
                              </span>
                              <a
                                href={waUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="px-1.5 py-0.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-semibold flex items-center gap-1"
                                title="Chat in WhatsApp"
                              >
                                <MessageSquare className="w-2.5 h-2.5" />
                                <span>Chat</span>
                              </a>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Target className="w-3 h-3 text-zinc-400" />
                              <span className="text-zinc-700 dark:text-zinc-300 font-medium">{lead.interest}</span>
                            </div>
                            {lead.trialDate && (
                              <div className="flex items-center gap-1.5 font-mono text-zinc-800 dark:text-zinc-200">
                                <Calendar className="w-3 h-3" />
                                <span>{lead.trialDate}</span>
                              </div>
                            )}
                          </div>

                          {lead.notes && (
                            <p className="text-[10px] text-zinc-500 bg-white dark:bg-zinc-950 p-2 rounded-lg mb-3 italic border border-zinc-200 dark:border-zinc-800">
                              "{lead.notes}"
                            </p>
                          )}

                          {/* Footer & Stage Shift */}
                          <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
                            <span className="text-[10px] text-zinc-400">
                              Coach: <strong className="text-zinc-700 dark:text-zinc-300 font-medium">{lead.assignedStaff}</strong>
                            </span>

                            <div className="flex items-center gap-1">
                              {idx > 0 && (
                                <button
                                  onClick={() => updateLeadStage(lead.id, STAGES[idx - 1].id)}
                                  className="p-1 text-zinc-400 hover:text-zinc-900 dark:hover:text-white rounded"
                                  title="Move back"
                                >
                                  <ArrowLeft className="w-3 h-3" />
                                </button>
                              )}
                              {idx < STAGES.length - 1 && (
                                <button
                                  onClick={() => updateLeadStage(lead.id, STAGES[idx + 1].id)}
                                  className="p-1 text-zinc-400 hover:text-zinc-900 dark:hover:text-white rounded"
                                  title="Advance stage"
                                >
                                  <ArrowRight className="w-3 h-3" />
                                </button>
                              )}
                              <button
                                onClick={() => deleteLead(lead.id)}
                                className="p-1 text-zinc-400 hover:text-rose-500 rounded ml-1"
                                title="Delete lead"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
