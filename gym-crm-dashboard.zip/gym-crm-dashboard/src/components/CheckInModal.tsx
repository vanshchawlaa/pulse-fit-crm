import React, { useState } from 'react';
import { X, QrCode, Search, CheckCircle2, AlertCircle } from 'lucide-react';
import { useGym } from '../context/GymContext';

export const CheckInModal: React.FC = () => {
  const { isCheckInModalOpen, setIsCheckInModalOpen, checkInMember, members } = useGym();
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isCheckInModalOpen) return null;

  const handleCheckIn = (memberIdOrName: string) => {
    const res = checkInMember(memberIdOrName);
    setResult(res);
    if (res.success) {
      setTimeout(() => {
        setResult(null);
        setQuery('');
        setIsCheckInModalOpen(false);
      }, 1400);
    }
  };

  const matchedMembers = query.trim()
    ? members.filter(
        (m) =>
          m.name.toLowerCase().includes(query.toLowerCase()) ||
          m.phone.includes(query) ||
          m.id.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 dark:bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white dark:bg-[#121214] border border-zinc-200 dark:border-white/[0.1] rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-fade-in-up">
        {/* Header */}
        <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-black dark:bg-white text-white dark:text-black flex items-center justify-center font-bold">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-zinc-900 dark:text-white">Turnstile Member Check-In</h3>
              <p className="text-[11px] text-zinc-500">Front Desk RFID & Optical Scanner</p>
            </div>
          </div>
          <button
            onClick={() => {
              setIsCheckInModalOpen(false);
              setResult(null);
            }}
            className="p-1.5 text-zinc-400 hover:text-zinc-900 dark:hover:text-white rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          {/* Status Message Alert */}
          {result && (
            <div
              className={`p-3.5 rounded-2xl flex items-center gap-3 text-xs font-medium animate-fade-in ${
                result.success
                  ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white border border-zinc-300 dark:border-zinc-700'
                  : 'bg-zinc-100 dark:bg-zinc-800 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-700'
              }`}
            >
              {result.success ? <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" /> : <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />}
              <span>{result.message}</span>
            </div>
          )}

          {/* Search Input */}
          <div>
            <label className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 block mb-1.5">
              Enter Member Name, RFID tag, or Phone
            </label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="e.g. Marcus, Chloe, or 555..."
                className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 transition-all font-medium"
              />
            </div>
          </div>

          {/* Quick Match Candidates */}
          {matchedMembers.length > 0 ? (
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              <span className="text-[10px] uppercase font-mono text-zinc-500 tracking-wider">Matching Members:</span>
              {matchedMembers.map((m) => (
                <div
                  key={m.id}
                  onClick={() => handleCheckIn(m.id)}
                  className="flex items-center justify-between p-2.5 bg-zinc-50 dark:bg-zinc-900/60 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800 rounded-xl cursor-pointer transition-all duration-150"
                >
                  <div className="flex items-center gap-2.5">
                    <img src={m.avatar} alt={m.name} className="w-7 h-7 rounded-full object-cover ring-1 ring-zinc-300 dark:ring-zinc-700" />
                    <div>
                      <div className="text-xs font-semibold text-zinc-900 dark:text-white">{m.name}</div>
                      <div className="text-[10px] text-zinc-500">{m.plan}</div>
                    </div>
                  </div>
                  <button className="px-2.5 py-1 bg-zinc-900 dark:bg-white text-white dark:text-black text-xs font-semibold rounded-lg shadow-sm">
                    Check In
                  </button>
                </div>
              ))}
            </div>
          ) : query.trim() ? (
            <div className="p-4 text-center text-xs text-zinc-500">
              No matching member found for "{query}"
            </div>
          ) : null}

          {/* Preset One-Click Demos */}
          <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800">
            <span className="text-[11px] text-zinc-500 block mb-2 font-medium">Quick 1-Click Test Scans:</span>
            <div className="grid grid-cols-2 gap-2">
              {members.slice(0, 2).map((m) => (
                <button
                  key={m.id}
                  onClick={() => handleCheckIn(m.id)}
                  className="p-2.5 bg-zinc-50 dark:bg-zinc-900/60 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800 rounded-xl text-left transition-all duration-150 group"
                >
                  <div className="text-xs font-semibold text-zinc-900 dark:text-white truncate">{m.name}</div>
                  <div className="text-[10px] text-zinc-500 font-mono">{m.plan}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
