import React, { useState } from 'react';
import { Award, Star, Users, MessageSquare, Plus, Edit2, Trash2, X, Check, Save } from 'lucide-react';
import { useGym } from '../context/GymContext';
import { Trainer } from '../types';

const EMPTY_TRAINER: Omit<Trainer, 'id'> = {
  name: '',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  role: 'Personal Trainer',
  specialty: '',
  activeClients: 0,
  rating: 5.0,
  sessionsCompletedThisMonth: 0,
  hourlyRate: 500,
  status: 'On Floor',
};

const AVATAR_OPTIONS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
];

export const TrainersView: React.FC = () => {
  const { trainers, setActiveView, addTrainer, updateTrainer, deleteTrainer, currency, formatPrice } = useGym();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTrainer, setEditingTrainer] = useState<Trainer | null>(null);
  const [form, setForm] = useState<Omit<Trainer, 'id'>>(EMPTY_TRAINER);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const openAdd = () => {
    setEditingTrainer(null);
    setForm(EMPTY_TRAINER);
    setIsModalOpen(true);
  };

  const openEdit = (trainer: Trainer) => {
    setEditingTrainer(trainer);
    setForm({ ...trainer });
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!form.name.trim()) return;
    if (editingTrainer) {
      updateTrainer(editingTrainer.id, form);
    } else {
      addTrainer(form);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    deleteTrainer(id);
    setDeleteConfirm(null);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* Header Info */}
      <div className="glass-panel p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-zinc-900 dark:text-white tracking-tight flex items-center gap-2">
            <Award className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
            <span>Coaches & Personal Training Staff ({trainers.length})</span>
          </h2>
          <p className="text-xs text-zinc-500">
            Monitor client roster sizes, session delivery rates, and floor availability.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[11px] font-mono text-zinc-800 dark:text-zinc-200 bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-3 py-1.5 rounded-xl">
            {trainers.reduce((s, t) => s + t.sessionsCompletedThisMonth, 0)} PT Sessions This Month
          </span>
          <button
            onClick={openAdd}
            className="flex items-center gap-1.5 px-4 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-xl text-xs font-semibold hover:bg-zinc-700 dark:hover:bg-zinc-100 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Coach
          </button>
        </div>
      </div>

      {/* Trainers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {trainers.map((trn) => (
          <div
            key={trn.id}
            className="glass-panel glass-panel-hover rounded-2xl p-5 shadow-sm flex flex-col justify-between group"
          >
            <div>
              {/* Avatar + Status */}
              <div className="relative mb-4">
                <img
                  src={trn.avatar}
                  alt={trn.name}
                  className="w-20 h-20 rounded-2xl object-cover ring-1 ring-zinc-200 dark:ring-zinc-800 mx-auto shadow-sm"
                />
                <span className={`absolute -bottom-2 right-1/2 translate-x-10 px-2 py-0.5 rounded-full text-[10px] font-mono border ${
                  trn.status === 'On Floor' ? 'bg-black dark:bg-white text-white dark:text-black font-semibold' :
                  trn.status === 'In Session' ? 'bg-zinc-200 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold border-zinc-300 dark:border-zinc-700' :
                  'bg-zinc-100 dark:bg-zinc-900 text-zinc-500 border-zinc-200 dark:border-zinc-800'
                }`}>
                  {trn.status}
                </span>
              </div>

              <div className="text-center mb-3">
                <h3 className="font-semibold text-sm text-zinc-900 dark:text-white">
                  {trn.name}
                </h3>
                <p className="text-[11px] text-zinc-500 font-medium mt-0.5">{trn.role}</p>
                <div className="flex items-center justify-center gap-1 mt-1 text-zinc-800 dark:text-zinc-200 text-xs font-mono">
                  <Star className="w-3.5 h-3.5 fill-current text-zinc-900 dark:text-white" />
                  <span>{trn.rating} <span className="text-zinc-400">/ 5.0</span></span>
                </div>
              </div>

              {/* Specialty */}
              <div className="p-2.5 bg-zinc-50 dark:bg-zinc-900/40 rounded-xl border border-zinc-200 dark:border-zinc-800 text-[11px] text-zinc-700 dark:text-zinc-300 text-center mb-3">
                {trn.specialty || 'General Fitness'}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-2 text-xs py-2.5 border-y border-zinc-200 dark:border-zinc-800 mb-4">
                <div>
                  <span className="text-[10px] text-zinc-500 block">Active PT Clients</span>
                  <span className="font-semibold text-zinc-900 dark:text-white font-mono">{trn.activeClients}</span>
                </div>
                <div>
                  <span className="text-[10px] text-zinc-500 block">Session Rate</span>
                  <span className="font-semibold text-zinc-900 dark:text-white font-mono">{formatPrice(trn.hourlyRate)}/hr</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => openEdit(trn)}
                className="flex-1 py-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-900 dark:text-white rounded-xl text-xs font-medium border border-zinc-300 dark:border-zinc-800 transition-colors flex items-center justify-center gap-1.5"
              >
                <Edit2 className="w-3 h-3" />
                <span>Edit</span>
              </button>
              {deleteConfirm === trn.id ? (
                <div className="flex gap-1">
                  <button
                    onClick={() => handleDelete(trn.id)}
                    className="p-2 rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(null)}
                    className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setDeleteConfirm(trn.id)}
                  className="p-2 bg-zinc-100 hover:bg-red-100 dark:bg-zinc-900 dark:hover:bg-red-900/20 text-zinc-500 hover:text-red-500 rounded-xl border border-zinc-300 dark:border-zinc-800 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        ))}

        {/* Add Coach Card */}
        <button
          onClick={openAdd}
          className="glass-panel rounded-2xl p-5 shadow-sm border-2 border-dashed border-zinc-300 dark:border-zinc-700 flex flex-col items-center justify-center gap-3 text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-500 transition-all min-h-[280px]"
        >
          <Plus className="w-8 h-8" />
          <span className="text-sm font-medium">Add New Coach</span>
        </button>
      </div>

      {/* Add/Edit Coach Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-950 rounded-2xl shadow-2xl border border-zinc-200 dark:border-zinc-800 w-full max-w-md max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="sticky top-0 bg-white dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-800 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
              <h3 className="font-semibold text-sm text-zinc-900 dark:text-white">
                {editingTrainer ? 'Edit Coach' : 'Add New Coach'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Avatar Selection */}
              <div>
                <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-2">
                  Profile Photo
                </label>
                <div className="flex gap-2 flex-wrap">
                  {AVATAR_OPTIONS.map((url) => (
                    <button
                      key={url}
                      onClick={() => setForm(p => ({ ...p, avatar: url }))}
                      className={`w-10 h-10 rounded-xl overflow-hidden ring-2 transition-all ${
                        form.avatar === url ? 'ring-zinc-900 dark:ring-white' : 'ring-transparent hover:ring-zinc-400'
                      }`}
                    >
                      <img src={url} alt="avatar" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={form.avatar}
                  onChange={e => setForm(p => ({ ...p, avatar: e.target.value }))}
                  placeholder="Or paste image URL"
                  className="mt-2 w-full px-3 py-2 text-xs bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400"
                />
              </div>

              {/* Name */}
              <div>
                <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="e.g. Arjun Singh"
                  className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400"
                />
              </div>

              {/* Role */}
              <div>
                <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                  Role / Title
                </label>
                <select
                  value={form.role}
                  onChange={e => setForm(p => ({ ...p, role: e.target.value }))}
                  className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-zinc-400"
                >
                  <option>Personal Trainer</option>
                  <option>Head Coach</option>
                  <option>CrossFit Coach</option>
                  <option>Yoga Instructor</option>
                  <option>Strength & Conditioning Coach</option>
                  <option>Nutrition Coach</option>
                  <option>Rehabilitation Specialist</option>
                  <option>Boxing Coach</option>
                  <option>Spin Instructor</option>
                </select>
              </div>

              {/* Specialty */}
              <div>
                <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                  Specialty
                </label>
                <input
                  type="text"
                  value={form.specialty}
                  onChange={e => setForm(p => ({ ...p, specialty: e.target.value }))}
                  placeholder="e.g. HIIT, Weight Loss, Muscle Building"
                  className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400"
                />
              </div>

              {/* Stats Row */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Active Clients
                  </label>
                  <input
                    type="number"
                    value={form.activeClients}
                    onChange={e => setForm(p => ({ ...p, activeClients: Number(e.target.value) }))}
                    min={0}
                    className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Hourly Rate ({currency.symbol})
                  </label>
                  <input
                    type="number"
                    value={form.hourlyRate}
                    onChange={e => setForm(p => ({ ...p, hourlyRate: Number(e.target.value) }))}
                    min={0}
                    className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-zinc-400"
                  />
                </div>
              </div>

              {/* Rating + Status */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Rating (out of 5)
                  </label>
                  <input
                    type="number"
                    value={form.rating}
                    onChange={e => setForm(p => ({ ...p, rating: Math.min(5, Math.max(0, Number(e.target.value))) }))}
                    min={0} max={5} step={0.1}
                    className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Current Status
                  </label>
                  <select
                    value={form.status}
                    onChange={e => setForm(p => ({ ...p, status: e.target.value as Trainer['status'] }))}
                    className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-zinc-400"
                  >
                    <option value="On Floor">On Floor</option>
                    <option value="In Session">In Session</option>
                    <option value="Off Duty">Off Duty</option>
                  </select>
                </div>
              </div>

              {/* Sessions this month */}
              <div>
                <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                  Sessions Completed This Month
                </label>
                <input
                  type="number"
                  value={form.sessionsCompletedThisMonth}
                  onChange={e => setForm(p => ({ ...p, sessionsCompletedThisMonth: Number(e.target.value) }))}
                  min={0}
                  className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-zinc-400"
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-white dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-800 px-6 py-4 flex gap-3 rounded-b-2xl">
              <button
                onClick={() => setIsModalOpen(false)}
                className="flex-1 py-2.5 text-sm font-medium text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={!form.name.trim()}
                className="flex-1 py-2.5 text-sm font-semibold text-white dark:text-zinc-900 bg-zinc-900 dark:bg-white rounded-xl hover:bg-zinc-700 dark:hover:bg-zinc-100 transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Save className="w-3.5 h-3.5" />
                {editingTrainer ? 'Save Changes' : 'Add Coach'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
