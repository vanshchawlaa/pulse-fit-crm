import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Check, X, CreditCard, Star, Users, Clock, Zap } from 'lucide-react';
import { useGym } from '../context/GymContext';

interface PlanFeature {
  text: string;
  included: boolean;
}

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  billingCycle: 'monthly' | 'quarterly' | 'annually';
  color: string;
  badge?: string;
  features: PlanFeature[];
  maxMembers?: number;
  isActive: boolean;
  createdAt: string;
}

const DEFAULT_PLANS: SubscriptionPlan[] = [
  {
    id: 'plan-1',
    name: 'Standard Fitness',
    price: 79,
    billingCycle: 'monthly',
    color: 'zinc',
    features: [
      { text: 'Full gym floor access', included: true },
      { text: 'Locker room access', included: true },
      { text: 'Group classes (2/week)', included: true },
      { text: 'Personal trainer sessions', included: false },
      { text: 'Spa & recovery suite', included: false },
      { text: 'Guest passes', included: false },
    ],
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: 'plan-2',
    name: 'CrossFit Pro',
    price: 149,
    billingCycle: 'monthly',
    color: 'zinc',
    badge: 'Popular',
    features: [
      { text: 'Full gym floor access', included: true },
      { text: 'Locker room access', included: true },
      { text: 'Unlimited group classes', included: true },
      { text: '2 PT sessions/month', included: true },
      { text: 'Spa & recovery suite', included: false },
      { text: '1 Guest pass/month', included: true },
    ],
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: 'plan-3',
    name: 'All-Access VIP',
    price: 179,
    billingCycle: 'monthly',
    color: 'zinc',
    badge: 'Best Value',
    features: [
      { text: 'Full gym floor access', included: true },
      { text: 'Locker room access', included: true },
      { text: 'Unlimited group classes', included: true },
      { text: '4 PT sessions/month', included: true },
      { text: 'Spa & recovery suite', included: true },
      { text: '3 Guest passes/month', included: true },
    ],
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: 'plan-4',
    name: 'Yoga & Pilates Studio',
    price: 99,
    billingCycle: 'monthly',
    color: 'zinc',
    features: [
      { text: 'Yoga studio access', included: true },
      { text: 'Pilates classes (unlimited)', included: true },
      { text: 'Locker room access', included: true },
      { text: 'Gym floor access', included: false },
      { text: 'Personal trainer sessions', included: false },
      { text: 'Guest passes', included: false },
    ],
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: 'plan-5',
    name: 'Student / Off-Peak',
    price: 49,
    billingCycle: 'monthly',
    color: 'zinc',
    features: [
      { text: 'Off-peak hours access (6am–4pm)', included: true },
      { text: 'Locker room access', included: true },
      { text: 'Group classes (1/week)', included: true },
      { text: 'Peak hours access', included: false },
      { text: 'Personal trainer sessions', included: false },
      { text: 'Guest passes', included: false },
    ],
    isActive: true,
    createdAt: '2024-01-01',
  },
];

const BILLING_LABELS = {
  monthly: '/mo',
  quarterly: '/qtr',
  annually: '/yr',
};

const EMPTY_PLAN: Omit<SubscriptionPlan, 'id' | 'createdAt'> = {
  name: '',
  price: 0,
  billingCycle: 'monthly',
  color: 'zinc',
  badge: '',
  features: [
    { text: '', included: true },
    { text: '', included: true },
    { text: '', included: false },
  ],
  isActive: true,
};

export const SubscriptionPlansView: React.FC = () => {
  const { currency, formatPrice } = useGym();
  const [plans, setPlans] = useState<SubscriptionPlan[]>(() => {
    const saved = localStorage.getItem('gym_crm_subscription_plans');
    return saved ? JSON.parse(saved) : DEFAULT_PLANS;
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null);
  const [form, setForm] = useState<Omit<SubscriptionPlan, 'id' | 'createdAt'>>(EMPTY_PLAN);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const savePlans = (updated: SubscriptionPlan[]) => {
    setPlans(updated);
    localStorage.setItem('gym_crm_subscription_plans', JSON.stringify(updated));
  };

  const openAdd = () => {
    setEditingPlan(null);
    setForm(EMPTY_PLAN);
    setIsModalOpen(true);
  };

  const openEdit = (plan: SubscriptionPlan) => {
    setEditingPlan(plan);
    setForm({ ...plan });
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!form.name.trim() || form.price <= 0) return;
    if (editingPlan) {
      savePlans(plans.map(p => p.id === editingPlan.id ? { ...editingPlan, ...form } : p));
    } else {
      const newPlan: SubscriptionPlan = {
        ...form,
        id: `plan-${Date.now()}`,
        createdAt: new Date().toISOString().split('T')[0],
      };
      savePlans([...plans, newPlan]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    savePlans(plans.filter(p => p.id !== id));
    setDeleteConfirm(null);
  };

  const toggleActive = (id: string) => {
    savePlans(plans.map(p => p.id === id ? { ...p, isActive: !p.isActive } : p));
  };

  const updateFeature = (idx: number, field: 'text' | 'included', value: string | boolean) => {
    setForm(prev => ({
      ...prev,
      features: prev.features.map((f, i) => i === idx ? { ...f, [field]: value } : f),
    }));
  };

  const addFeature = () => {
    setForm(prev => ({ ...prev, features: [...prev.features, { text: '', included: true }] }));
  };

  const removeFeature = (idx: number) => {
    setForm(prev => ({ ...prev, features: prev.features.filter((_, i) => i !== idx) }));
  };

  const activePlans = plans.filter(p => p.isActive);
  const totalRevenuePotential = plans.reduce((sum, p) => sum + p.price, 0);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="glass-panel p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-zinc-900 dark:text-white tracking-tight flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
            <span>Membership Subscription Plans ({plans.length})</span>
          </h2>
          <p className="text-xs text-zinc-500 mt-0.5">
            Create, edit and manage all gym membership tiers and pricing.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[11px] font-mono text-zinc-800 dark:text-zinc-200 bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-3 py-1.5 rounded-xl">
            {activePlans.length} Active Plans
          </span>
          <button
            onClick={openAdd}
            className="flex items-center gap-1.5 px-4 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-xl text-xs font-semibold hover:bg-zinc-700 dark:hover:bg-zinc-100 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            New Plan
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Plans', value: plans.length, icon: CreditCard },
          { label: 'Active Plans', value: activePlans.length, icon: Zap },
          { label: 'Lowest Price', value: `${formatPrice(Math.min(...plans.map(p => p.price)))}/mo`, icon: Star },
          { label: 'Highest Price', value: `${formatPrice(Math.max(...plans.map(p => p.price)))}/mo`, icon: Users },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="glass-panel rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-1">
              <Icon className="w-3.5 h-3.5 text-zinc-500" />
              <span className="text-[11px] text-zinc-500">{label}</span>
            </div>
            <span className="text-lg font-bold font-mono text-zinc-900 dark:text-white">{value}</span>
          </div>
        ))}
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`glass-panel rounded-2xl p-5 shadow-sm flex flex-col justify-between border transition-all ${
              plan.isActive
                ? 'border-zinc-200 dark:border-zinc-700'
                : 'border-dashed border-zinc-300 dark:border-zinc-700 opacity-60'
            }`}
          >
            {/* Plan Header */}
            <div>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-sm text-zinc-900 dark:text-white">{plan.name}</h3>
                    {plan.badge && (
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-full">
                        {plan.badge}
                      </span>
                    )}
                    {!plan.isActive && (
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-zinc-200 dark:bg-zinc-800 text-zinc-500 rounded-full">
                        Inactive
                      </span>
                    )}
                  </div>
                  <div className="mt-1.5 flex items-baseline gap-1">
                    <span className="text-2xl font-bold font-mono text-zinc-900 dark:text-white">
                      {formatPrice(plan.price)}
                    </span>
                    <span className="text-xs text-zinc-500">{BILLING_LABELS[plan.billingCycle]}</span>
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => openEdit(plan)}
                    className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-400 transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  {deleteConfirm === plan.id ? (
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleDelete(plan.id)}
                        className="p-1.5 rounded-lg bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(null)}
                        className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-600 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setDeleteConfirm(plan.id)}
                      className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-red-100 dark:hover:bg-red-900/30 text-zinc-600 dark:text-zinc-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Features */}
              <div className="space-y-1.5 mt-3 mb-4">
                {plan.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    {f.included ? (
                      <Check className="w-3.5 h-3.5 text-zinc-900 dark:text-white flex-shrink-0" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-zinc-400 flex-shrink-0" />
                    )}
                    <span className={f.included ? 'text-zinc-700 dark:text-zinc-300' : 'text-zinc-400 line-through'}>
                      {f.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Toggle */}
            <button
              onClick={() => toggleActive(plan.id)}
              className={`w-full py-2 rounded-xl text-xs font-medium border transition-colors ${
                plan.isActive
                  ? 'bg-zinc-100 dark:bg-zinc-900 border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-800'
                  : 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 border-transparent hover:bg-zinc-700'
              }`}
            >
              {plan.isActive ? 'Deactivate Plan' : 'Activate Plan'}
            </button>
          </div>
        ))}

        {/* Add Plan Card */}
        <button
          onClick={openAdd}
          className="glass-panel rounded-2xl p-5 shadow-sm border-2 border-dashed border-zinc-300 dark:border-zinc-700 flex flex-col items-center justify-center gap-3 text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-500 transition-all min-h-[200px]"
        >
          <Plus className="w-8 h-8" />
          <span className="text-sm font-medium">Create New Plan</span>
        </button>
      </div>

      {/* Plan Editor Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-950 rounded-2xl shadow-2xl border border-zinc-200 dark:border-zinc-800 w-full max-w-lg max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="sticky top-0 bg-white dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-800 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
              <h3 className="font-semibold text-sm text-zinc-900 dark:text-white">
                {editingPlan ? 'Edit Subscription Plan' : 'Create New Subscription Plan'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* Plan Name */}
              <div>
                <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                  Plan Name *
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="e.g. All-Access VIP"
                  className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400"
                />
              </div>

              {/* Price + Billing */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Price ({currency.symbol}) *
                  </label>
                  <input
                    type="number"
                    value={form.price || ''}
                    onChange={e => setForm(p => ({ ...p, price: Number(e.target.value) }))}
                    placeholder="999"
                    min={0}
                    className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Billing Cycle
                  </label>
                  <select
                    value={form.billingCycle}
                    onChange={e => setForm(p => ({ ...p, billingCycle: e.target.value as any }))}
                    className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-zinc-400"
                  >
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="annually">Annually</option>
                  </select>
                </div>
              </div>

              {/* Badge */}
              <div>
                <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                  Badge Label <span className="text-zinc-400">(optional)</span>
                </label>
                <input
                  type="text"
                  value={form.badge || ''}
                  onChange={e => setForm(p => ({ ...p, badge: e.target.value }))}
                  placeholder="e.g. Popular, Best Value"
                  className="w-full px-3 py-2.5 text-sm bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400"
                />
              </div>

              {/* Features */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
                    Plan Features
                  </label>
                  <button
                    onClick={addFeature}
                    className="text-[11px] flex items-center gap-1 text-zinc-500 hover:text-zinc-800 dark:hover:text-white transition-colors"
                  >
                    <Plus className="w-3 h-3" /> Add Feature
                  </button>
                </div>
                <div className="space-y-2">
                  {form.features.map((f, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <button
                        onClick={() => updateFeature(i, 'included', !f.included)}
                        className={`flex-shrink-0 w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                          f.included
                            ? 'bg-zinc-900 dark:bg-white border-zinc-900 dark:border-white'
                            : 'bg-transparent border-zinc-300 dark:border-zinc-600'
                        }`}
                      >
                        {f.included && <Check className="w-3 h-3 text-white dark:text-zinc-900" />}
                      </button>
                      <input
                        type="text"
                        value={f.text}
                        onChange={e => updateFeature(i, 'text', e.target.value)}
                        placeholder="Feature description"
                        className="flex-1 px-2.5 py-1.5 text-xs bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-zinc-400"
                      />
                      <button
                        onClick={() => removeFeature(i)}
                        className="p-1 text-zinc-400 hover:text-red-500 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Toggle */}
              <div className="flex items-center justify-between p-3 bg-zinc-50 dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800">
                <div>
                  <span className="text-xs font-medium text-zinc-900 dark:text-white">Plan Active</span>
                  <p className="text-[11px] text-zinc-500">Active plans are visible and assignable to members</p>
                </div>
                <button
                  onClick={() => setForm(p => ({ ...p, isActive: !p.isActive }))}
                  className={`w-10 h-5 rounded-full transition-colors relative flex-shrink-0 ${
                    form.isActive ? 'bg-zinc-900 dark:bg-white' : 'bg-zinc-300 dark:bg-zinc-700'
                  }`}
                >
                  <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white dark:bg-zinc-900 rounded-full shadow transition-transform ${
                    form.isActive ? 'translate-x-5' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-white dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-800 px-6 py-4 flex gap-3 rounded-b-2xl">
              <button
                onClick={() => setIsModalOpen(false)}
                className="flex-1 py-2.5 text-sm font-medium text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={!form.name.trim() || form.price <= 0}
                className="flex-1 py-2.5 text-sm font-semibold text-white dark:text-zinc-900 bg-zinc-900 dark:bg-white rounded-xl hover:bg-zinc-700 dark:hover:bg-zinc-100 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {editingPlan ? 'Save Changes' : 'Create Plan'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
