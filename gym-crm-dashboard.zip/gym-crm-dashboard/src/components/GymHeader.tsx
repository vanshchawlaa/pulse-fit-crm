import React, { useState, useRef, useEffect } from 'react';
import { Search, Sun, Moon, QrCode, Command, FileSpreadsheet, Send, ChevronDown, Check } from 'lucide-react';
import { useGym } from '../context/GymContext';
import { CURRENCIES } from '../context/GymContext';

export const GymHeader: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => {
  const { 
    searchQuery, 
    setSearchQuery, 
    darkMode, 
    setDarkMode, 
    setIsCheckInModalOpen, 
    setActiveView,
    currency,
    setCurrency,
  } = useGym();

  const [currencyOpen, setCurrencyOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setCurrencyOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <header className="h-16 border-b border-zinc-200 dark:border-white/[0.08] bg-white/90 dark:bg-black/90 backdrop-blur-xl px-6 flex items-center justify-between sticky top-0 z-10 select-none transition-colors duration-200">
      {/* Title & View Context */}
      <div>
        <h1 className="text-base font-bold text-zinc-900 dark:text-white tracking-tight flex items-center gap-2">
          {title}
        </h1>
        {subtitle && (
          <p className="text-[11px] text-zinc-500 font-normal">{subtitle}</p>
        )}
      </div>

      {/* Global Member & Class Search */}
      <div className="relative w-80 max-w-sm hidden md:block">
        <Search className="w-3.5 h-3.5 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search members, RFID, phone, or class..."
          className="w-full bg-zinc-100 dark:bg-zinc-900 text-zinc-900 dark:text-white text-xs rounded-xl pl-9 pr-12 py-2 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 focus:border-zinc-500 dark:focus:border-zinc-400 outline-none transition-all duration-200 placeholder:text-zinc-400"
        />
        <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-0.5 pointer-events-none text-[10px] text-zinc-400 font-mono bg-zinc-200/60 dark:bg-zinc-800 px-1.5 py-0.5 rounded">
          <Command className="w-2.5 h-2.5" />
          <span>K</span>
        </div>
      </div>

      {/* Right Controls & Quick Actions */}
      <div className="flex items-center space-x-2.5">
        {/* Quick Excel Import Button */}
        <button
          onClick={() => setActiveView('import')}
          className="hidden sm:flex items-center gap-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-800 text-xs font-semibold px-3 py-1.5 rounded-xl transition-all duration-150"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Import Excel</span>
        </button>

        {/* Quick Marketing Hub Button */}
        <button
          onClick={() => setActiveView('marketing')}
          className="hidden sm:flex items-center gap-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-800 text-xs font-semibold px-3 py-1.5 rounded-xl transition-all duration-150"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Marketing</span>
        </button>

        {/* 💱 Currency Selector */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setCurrencyOpen(!currencyOpen)}
            className="flex items-center gap-1.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-800 text-xs font-semibold px-3 py-1.5 rounded-xl transition-all duration-150"
            title="Change Currency"
          >
            <span className="font-mono text-sm leading-none">{currency.symbol}</span>
            <span className="hidden sm:inline">{currency.code}</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${currencyOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Dropdown */}
          {currencyOpen && (
            <div className="absolute right-0 top-full mt-2 w-56 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl z-50 overflow-hidden animate-fade-in">
              <div className="px-3 py-2.5 border-b border-zinc-100 dark:border-zinc-800">
                <span className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Select Currency</span>
              </div>
              <div className="max-h-72 overflow-y-auto py-1">
                {CURRENCIES.map((c) => (
                  <button
                    key={c.code}
                    onClick={() => { setCurrency(c); setCurrencyOpen(false); }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-xs hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-colors ${
                      currency.code === c.code ? 'text-zinc-900 dark:text-white font-semibold' : 'text-zinc-600 dark:text-zinc-400'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 text-center font-mono text-sm text-zinc-900 dark:text-white">{c.symbol}</span>
                      <div className="text-left">
                        <div className="font-medium">{c.code}</div>
                        <div className="text-[10px] text-zinc-400">{c.name}</div>
                      </div>
                    </div>
                    {currency.code === c.code && (
                      <Check className="w-3.5 h-3.5 text-zinc-900 dark:text-white flex-shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Turnstile Scanner */}
        <button
          onClick={() => setIsCheckInModalOpen(true)}
          className="flex items-center gap-1.5 bg-black hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-black text-xs font-semibold px-3 py-1.5 rounded-xl shadow-sm transition-all duration-150 active:scale-95"
        >
          <QrCode className="w-3.5 h-3.5" />
          <span>Scan Pass</span>
        </button>

        {/* Light / Dark Mode Toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="p-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 transition-all duration-150"
          title={darkMode ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
        >
          {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-zinc-700" />}
        </button>
      </div>
    </header>
  );
};
