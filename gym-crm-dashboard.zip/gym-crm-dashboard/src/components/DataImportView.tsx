import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { 
  FileSpreadsheet, 
  Upload, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Users, 
  Target, 
  Check, 
  RefreshCw,
  Trash2
} from 'lucide-react';
import { useGym } from '../context/GymContext';
import { Member, Lead, MembershipPlan } from '../types';

export const DataImportView: React.FC = () => {
  const { importMembersFromData, importLeadsFromData, setActiveView } = useGym();
  
  const [importTarget, setImportTarget] = useState<'members' | 'leads'>('members');
  const [parsedRows, setParsedRows] = useState<any[]>([]);
  const [fileName, setFileName] = useState<string>('');
  const [importStatus, setImportStatus] = useState<{ count: number; target: string } | null>(null);
  const [pasteData, setPasteData] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Process raw parsed rows into CRM data
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (json.length < 2) {
          alert('Spreadsheet seems empty or missing header row.');
          return;
        }

        const headers = (json[0] as string[]).map((h) => String(h).trim().toLowerCase());
        const dataRows = (json.slice(1) as any[]).filter((row) => row && row.length > 0);

        const mapped = dataRows.map((row) => {
          const item: any = {};
          headers.forEach((h, idx) => {
            const val = row[idx];
            if (val === undefined || val === null) return;
            const cleanVal = String(val).trim();

            if (h.includes('name')) item.name = cleanVal;
            else if (h.includes('phone') || h.includes('mobile')) item.phone = cleanVal;
            else if (h.includes('email') || h.includes('mail')) item.email = cleanVal;
            else if (h.includes('plan') || h.includes('tier')) item.plan = cleanVal;
            else if (h.includes('status')) item.status = cleanVal;
            else if (h.includes('trainer') || h.includes('coach')) item.assignedTrainer = cleanVal;
            else if (h.includes('locker')) item.lockerNumber = cleanVal;
            else if (h.includes('goal')) item.fitnessGoal = cleanVal;
            else if (h.includes('fee') || h.includes('price')) item.monthlyFee = Number(cleanVal) || 79;
          });
          return item;
        }).filter((r) => r.name && r.name.length > 0);

        setParsedRows(mapped);
      } catch (err) {
        alert('Could not parse spreadsheet file. Please check file format.');
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // Parse pasted clipboard text
  const handleParseClipboard = () => {
    if (!pasteData.trim()) return;
    const lines = pasteData.trim().split('\n');
    if (lines.length === 0) return;

    const mapped = lines.map((line) => {
      const parts = line.split(/[,\t]/).map((p) => p.trim());
      return {
        name: parts[0] || 'Member',
        phone: parts[1] || '+1 (555) 000-0000',
        email: parts[2] || `${(parts[0] || 'member').toLowerCase().replace(/\s+/g, '')}@gymmember.com`,
        plan: parts[3] || 'Standard Fitness',
        status: parts[4] || 'Active',
      };
    }).filter((r) => r.name && r.name.length > 0);

    setFileName('Pasted Clipboard Table');
    setParsedRows(mapped);
  };

  // Download Sample Template
  const handleDownloadSample = () => {
    const sampleHeaders = ['Name', 'Phone', 'Email', 'Plan', 'Status', 'Coach', 'Locker', 'Fitness Goal'];
    const sampleData = [
      ['Jordan Hayes', '+1 (555) 789-0123', 'jordan.h@example.com', 'All-Access VIP', 'Active', 'Alex Rivera', 'L-12', 'Strength & Recomp'],
      ['Maya Patel', '+1 (555) 890-1234', 'maya.p@example.com', 'CrossFit Pro', 'Active', 'Brock Harrison', 'L-24', 'Endurance & Mobility'],
      ['Liam O Connor', '+1 (555) 901-2345', 'liam.oc@example.com', 'Standard Fitness', 'Expiring Soon', 'Elena Cruz', 'L-30', 'Fat Loss'],
      ['Sophia Rossi', '+1 (555) 012-3456', 'sophia.r@example.com', 'Yoga & Pilates Studio', 'Active', 'Maya Lin', 'L-05', 'Core & Posture'],
    ];

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet([sampleHeaders, ...sampleData]);
    XLSX.utils.book_append_sheet(wb, ws, 'Sample_Members');
    XLSX.writeFile(wb, 'pulsefit_member_import_template.xlsx');
  };

  // Execute Import into CRM Database
  const handleCommitImport = () => {
    if (parsedRows.length === 0) return;

    let importedCount = 0;
    if (importTarget === 'members') {
      importedCount = importMembersFromData(parsedRows);
    } else {
      importedCount = importLeadsFromData(parsedRows);
    }

    setImportStatus({ count: importedCount, target: importTarget });
    setParsedRows([]);
    setFileName('');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* Top Banner */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-700 font-semibold">
              Data Ingestion
            </span>
            <span className="text-xs text-zinc-500 font-mono">Excel (.xlsx, .xls) & CSV Engine</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white">
            Excel & Spreadsheet Member Import
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
            Bulk onboard members, client rosters, and marketing guest leads directly from Excel files or copy-pasted tables.
          </p>
        </div>

        {/* Download Template Action */}
        <button
          onClick={handleDownloadSample}
          className="px-4 py-2.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shrink-0 shadow-sm"
        >
          <Download className="w-4 h-4 text-zinc-600 dark:text-zinc-400" />
          <span>Download Sample Template (.xlsx)</span>
        </button>
      </div>

      {/* Success Notification Alert */}
      {importStatus && (
        <div className="p-4 rounded-2xl bg-zinc-900 dark:bg-white text-white dark:text-black flex items-center justify-between shadow-xl animate-fade-in">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 dark:text-emerald-600" />
            <div>
              <div className="text-xs font-bold">Import Successful!</div>
              <div className="text-[11px] opacity-80">
                Added {importStatus.count} new records directly into your {importStatus.target === 'members' ? 'Members Directory' : 'Leads Pipeline'}.
              </div>
            </div>
          </div>
          <button
            onClick={() => setActiveView(importStatus.target === 'members' ? 'members' : 'leads')}
            className="px-3.5 py-1.5 rounded-xl bg-white dark:bg-black text-black dark:text-white text-xs font-bold transition-transform active:scale-95"
          >
            View in {importStatus.target === 'members' ? 'Directory' : 'Pipeline'} →
          </button>
        </div>
      )}

      {/* Main Upload / Ingestion Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Upload Zone */}
        <div className="lg:col-span-6 space-y-4">
          <div className="glass-panel p-6 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300">
                1. Select Import Destination
              </h3>
              <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-xl border border-zinc-200 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setImportTarget('members')}
                  className={`text-xs px-3 py-1 rounded-lg font-semibold transition-all ${
                    importTarget === 'members'
                      ? 'bg-zinc-900 dark:bg-white text-white dark:text-black shadow-sm'
                      : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
                  }`}
                >
                  Members Directory
                </button>
                <button
                  type="button"
                  onClick={() => setImportTarget('leads')}
                  className={`text-xs px-3 py-1 rounded-lg font-semibold transition-all ${
                    importTarget === 'leads'
                      ? 'bg-zinc-900 dark:bg-white text-white dark:text-black shadow-sm'
                      : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
                  }`}
                >
                  Sales Pipeline Leads
                </button>
              </div>
            </div>

            {/* Drag & Drop File Box */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 hover:border-zinc-500 dark:hover:border-zinc-400 bg-zinc-50 dark:bg-zinc-900/40 rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div className="w-12 h-12 rounded-2xl bg-zinc-200 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300 mx-auto mb-3 group-hover:scale-110 transition-transform">
                <Upload className="w-6 h-6" />
              </div>
              <div className="text-xs font-semibold text-zinc-900 dark:text-white">
                Click to browse or drop your Excel file here
              </div>
              <div className="text-[11px] text-zinc-500 mt-1">
                Supports Microsoft Excel (.xlsx, .xls) and standard CSV
              </div>
            </div>

            {/* Quick Demo Preload Button */}
            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-zinc-500">Need immediate demo data?</span>
              <button
                type="button"
                onClick={() => {
                  setFileName('Demo_Batch_Upload.xlsx');
                  setParsedRows([
                    { name: 'Harrison Blake', phone: '+1 (555) 301-4422', email: 'harrison.b@example.com', plan: 'All-Access VIP', status: 'Active', assignedTrainer: 'Alex Rivera', lockerNumber: 'L-88', fitnessGoal: 'Powerlifting' },
                    { name: 'Nadia Petrova', phone: '+1 (555) 402-5533', email: 'nadia.p@example.com', plan: 'Yoga & Pilates Studio', status: 'Active', assignedTrainer: 'Maya Lin', lockerNumber: 'L-42', fitnessGoal: 'Mobility & Recovery' },
                    { name: 'Zane Gallagher', phone: '+1 (555) 503-6644', email: 'zane.g@example.com', plan: 'CrossFit Pro', status: 'Active', assignedTrainer: 'Brock Harrison', lockerNumber: 'L-19', fitnessGoal: 'Metcon Conditioning' },
                    { name: 'Camila Santos', phone: '+1 (555) 604-7755', email: 'camila.s@example.com', plan: 'Standard Fitness', status: 'Expiring Soon', assignedTrainer: 'Elena Cruz', lockerNumber: 'L-51', fitnessGoal: 'Strength & Core' },
                  ]);
                }}
                className="text-xs font-semibold text-zinc-900 dark:text-white hover:underline flex items-center gap-1"
              >
                <span>Preload 4 Sample Rows</span>
              </button>
            </div>
          </div>
        </div>

        {/* Or Paste Table Raw Text */}
        <div className="lg:col-span-6 space-y-4">
          <div className="glass-panel p-6 rounded-2xl space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300">
              2. Or Copy & Paste Directly from Excel
            </h3>
            <p className="text-[11px] text-zinc-500">
              Select cells in Excel or Google Sheets, press Ctrl+C, and paste below:
            </p>

            <textarea
              rows={4}
              value={pasteData}
              onChange={(e) => setPasteData(e.target.value)}
              placeholder="Name, Phone, Email, Plan, Status&#10;Julian Scott, +1 555-888-9999, julian@gym.com, All-Access VIP, Active"
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 text-xs text-zinc-900 dark:text-white outline-none focus:border-zinc-500 font-mono text-[11px]"
            />

            <button
              type="button"
              onClick={handleParseClipboard}
              disabled={!pasteData.trim()}
              className="w-full py-2 bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black rounded-xl text-xs font-semibold disabled:opacity-40 transition-colors"
            >
              Parse Pasted Rows
            </button>
          </div>
        </div>
      </div>

      {/* Parsed Data Preview Table */}
      {parsedRows.length > 0 && (
        <div className="glass-panel p-5 rounded-2xl space-y-4 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-200 dark:border-zinc-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-zinc-900 dark:text-white">
                  Ready to Import: {parsedRows.length} Rows
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700">
                  Source: {fileName}
                </span>
              </div>
              <p className="text-xs text-zinc-500 mt-0.5">
                Targeting destination: <strong className="text-zinc-900 dark:text-white capitalize">{importTarget}</strong>
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setParsedRows([])}
                className="px-3 py-2 text-xs font-medium text-rose-500 hover:bg-rose-500/10 rounded-xl transition-colors"
              >
                Clear
              </button>
              <button
                onClick={handleCommitImport}
                className="px-5 py-2.5 bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-black rounded-xl text-xs font-bold shadow-lg flex items-center gap-2 active:scale-95 transition-all"
              >
                <Check className="w-4 h-4" />
                <span>Confirm & Import All {parsedRows.length} Records</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[10px] font-mono uppercase text-zinc-500">
                  <th className="py-2 px-3">#</th>
                  <th className="py-2 px-3">Name</th>
                  <th className="py-2 px-3">Phone</th>
                  <th className="py-2 px-3">Email</th>
                  <th className="py-2 px-3">Plan / Tier</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3">Coach</th>
                  <th className="py-2 px-3">Locker</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/60 font-mono text-[11px]">
                {parsedRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/30">
                    <td className="py-2 px-3 text-zinc-400">{idx + 1}</td>
                    <td className="py-2 px-3 font-semibold text-zinc-900 dark:text-white font-sans">{row.name}</td>
                    <td className="py-2 px-3 text-zinc-600 dark:text-zinc-400">{row.phone}</td>
                    <td className="py-2 px-3 text-zinc-600 dark:text-zinc-400">{row.email}</td>
                    <td className="py-2 px-3 font-sans text-zinc-800 dark:text-zinc-200">{row.plan || 'Standard'}</td>
                    <td className="py-2 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200">
                        {row.status || 'Active'}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-sans text-zinc-600 dark:text-zinc-400">{row.assignedTrainer || 'Alex Rivera'}</td>
                    <td className="py-2 px-3 text-zinc-500">{row.lockerNumber || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
