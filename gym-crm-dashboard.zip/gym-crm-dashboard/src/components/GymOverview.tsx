import React from 'react';
import { 
  Users, 
  DollarSign, 
  QrCode, 
  TrendingUp, 
  CalendarDays, 
  ArrowUpRight, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  UserCheck,
  Send,
  FileSpreadsheet,
  ChevronRight,
  Zap
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { useGym } from '../context/GymContext';

const ATTENDANCE_TREND = [
  { day: 'Mon', visits: 310, newLeads: 12 },
  { day: 'Tue', visits: 345, newLeads: 15 },
  { day: 'Wed', visits: 290, newLeads: 9 },
  { day: 'Thu', visits: 360, newLeads: 18 },
  { day: 'Fri', visits: 280, newLeads: 11 },
  { day: 'Sat', visits: 410, newLeads: 24 },
  { day: 'Sun', visits: 260, newLeads: 8 },
];

export const GymOverview: React.FC = () => {
  const { 
    members, 
    classes, 
    checkIns, 
    totalActiveMembers, 
    monthlyRecurringRevenue, 
    todaysCheckInsCount, 
    floorCapacityPercentage, 
    leadConversionRate,
    bookClassSlot,
    setIsCheckInModalOpen,
    setIsNewMemberModalOpen,
    setActiveView,
    setSelectedMember,
    darkMode,
    formatPrice
  } = useGym();

  const expiringMembers = members.filter((m) => m.status === 'Expiring Soon');

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* High-End Monochrome Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-zinc-200 dark:border-white/[0.08] bg-zinc-950 text-white p-6 shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-white/10 border border-white/20 text-[10px] font-mono tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              <span>LIVE OPERATIONS ACTIVE</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white">
              Downtown Flagship Studio
            </h2>
            <p className="text-xs text-zinc-400 max-w-xl font-normal leading-relaxed">
              <span className="text-white font-semibold font-mono">{todaysCheckInsCount} workouts completed</span> today. Floor capacity pacing at {floorCapacityPercentage}%. Peak flow expected 5:00 PM – 7:30 PM.
            </p>
          </div>

          <div className="flex items-center gap-2.5 relative z-10">
            <button
              onClick={() => setActiveView('marketing')}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 rounded-xl transition-all duration-150 flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Campaign</span>
            </button>
            <button
              onClick={() => setIsCheckInModalOpen(true)}
              className="px-4 py-2.5 bg-white hover:bg-zinc-200 active:scale-95 text-black font-semibold text-xs rounded-xl shadow-lg transition-all duration-150 flex items-center gap-2"
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>Turnstile Scanner</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Minimalist Monochrome KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Active Members */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-500 mb-2">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-zinc-500">Active Members</span>
            <div className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white border border-zinc-200 dark:border-zinc-700">
              <Users className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-zinc-900 dark:text-white">
              {totalActiveMembers}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 font-medium mt-1.5">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span className="text-zinc-900 dark:text-white font-semibold">+14 this month</span>
              <span className="text-zinc-400">• 96% retention</span>
            </div>
          </div>
        </div>

        {/* Monthly Recurring Revenue */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-500 mb-2">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-zinc-500">Monthly Recurring</span>
            <div className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white border border-zinc-200 dark:border-zinc-700">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-zinc-900 dark:text-white">
              {formatPrice(monthlyRecurringRevenue * 12)} <span className="text-xs text-zinc-500 font-normal">/mo</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 font-medium mt-1.5">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span className="text-zinc-900 dark:text-white font-semibold">+8.4% pace</span>
              <span className="text-zinc-400">• Target met</span>
            </div>
          </div>
        </div>

        {/* Today's Workouts */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-500 mb-2">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-zinc-500">Today's Visits</span>
            <div className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white border border-zinc-200 dark:border-zinc-700">
              <UserCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-zinc-900 dark:text-white">
              {todaysCheckInsCount}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 font-medium mt-1.5">
              <Clock className="w-3.5 h-3.5" />
              <span>Avg: 58 mins</span>
              <span className="text-zinc-400">• Normal flow</span>
            </div>
          </div>
        </div>

        {/* Trial Conversion Rate */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-500 mb-2">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-zinc-500">Trial Close Rate</span>
            <div className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white border border-zinc-200 dark:border-zinc-700">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono tracking-tight text-zinc-900 dark:text-white">
              {leadConversionRate}%
            </div>
            <div className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 font-medium mt-1.5">
              <span className="text-zinc-900 dark:text-white font-semibold">+4.2%</span>
              <span className="text-zinc-400">• High momentum</span>
            </div>
          </div>
        </div>
      </div>

      {/* Chart and Expiring Members Warning Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance Area Chart */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold tracking-tight text-zinc-900 dark:text-white">
                Weekly Footfall Rhythm
              </h3>
              <p className="text-[11px] text-zinc-500">
                Daily member visits and inbound guest trial intakes
              </p>
            </div>
            <span className="text-[11px] font-mono bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 px-2.5 py-0.5 rounded-full">
              2,265 Visits / wk
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={ATTENDANCE_TREND} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="monoColorVisits" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={darkMode ? '#ffffff' : '#000000'} stopOpacity={0.2} />
                    <stop offset="95%" stopColor={darkMode ? '#ffffff' : '#000000'} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#27272a' : '#e4e4e7'} opacity={0.5} vertical={false} />
                <XAxis dataKey="day" stroke={darkMode ? '#71717a' : '#a1a1aa'} fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke={darkMode ? '#71717a' : '#a1a1aa'} fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: darkMode ? '#121214' : '#ffffff', 
                    borderColor: darkMode ? 'rgba(255,255,255,0.1)' : '#e4e4e7', 
                    borderRadius: '12px', 
                    fontSize: '11px',
                    color: darkMode ? '#ffffff' : '#000000',
                    boxShadow: '0 8px 30px rgba(0, 0, 0, 0.15)',
                  }}
                  formatter={(v: any, name: any) => [v, name === 'visits' ? 'Check-ins' : 'New Inbound Trials']}
                />
                <Area 
                  type="monotone" 
                  dataKey="visits" 
                  stroke={darkMode ? '#ffffff' : '#000000'} 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#monoColorVisits)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Expiring Soon & Retention Radar */}
        <div className="glass-panel rounded-2xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-white flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
                <span>Renewal Radar ({expiringMembers.length})</span>
              </h3>
              <span className="text-[10px] uppercase font-mono font-medium text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-2 py-0.5 rounded-full">
                14-day window
              </span>
            </div>
            <p className="text-[11px] text-zinc-500 mb-3">
              Members expiring soon. Launch a 1-click renewal campaign.
            </p>

            <div className="space-y-2">
              {expiringMembers.map((m) => (
                <div 
                  key={m.id}
                  onClick={() => setSelectedMember(m)}
                  className="p-3 bg-zinc-50 dark:bg-zinc-900/60 hover:bg-zinc-100 dark:hover:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl cursor-pointer transition-all duration-150"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-zinc-900 dark:text-white">{m.name}</span>
                    <span className="text-[10px] font-mono text-zinc-700 dark:text-zinc-300 bg-zinc-200/60 dark:bg-zinc-800 px-1.5 py-0.5 rounded">
                      Exp: {m.expirationDate}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-1 text-[11px] text-zinc-500">
                    <span>{m.plan}</span>
                    <span className="font-mono text-zinc-900 dark:text-white font-semibold">{formatPrice(m.monthlyFee)}/mo</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 mt-4">
            <button
              onClick={() => setActiveView('marketing')}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold bg-zinc-900 dark:bg-white text-white dark:text-black rounded-xl transition-all"
            >
              <Send className="w-3 h-3" />
              <span>WhatsApp Renewal</span>
            </button>
            <button
              onClick={() => setActiveView('members')}
              className="px-3 py-2 text-xs font-medium text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white border border-zinc-200 dark:border-zinc-800 rounded-xl"
            >
              Directory →
            </button>
          </div>
        </div>
      </div>

      {/* Today's Schedule & Live Stream Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Group Class Schedule */}
        <div className="glass-panel rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-white flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
                <span>Today's Group Classes</span>
              </h3>
              <p className="text-[11px] text-zinc-500">
                Live bookings and instructor studio roster
              </p>
            </div>
            <button
              onClick={() => setActiveView('classes')}
              className="text-xs text-zinc-700 dark:text-zinc-300 hover:underline font-semibold flex items-center gap-1"
            >
              <span>Full Timetable</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {classes.slice(0, 4).map((cls) => {
              const isFull = cls.bookedCount >= cls.capacity;
              return (
                <div 
                  key={cls.id}
                  className="p-3 bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-200 dark:border-zinc-800 rounded-xl flex items-center justify-between gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-zinc-900 dark:text-white truncate">{cls.name}</span>
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300">
                        {cls.category}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-zinc-500 mt-1">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-zinc-500" /> {cls.time}
                      </span>
                      <span>Coach: {cls.trainerName}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="text-xs font-mono font-semibold text-zinc-900 dark:text-white">
                        {cls.bookedCount} / {cls.capacity}
                      </div>
                      <div className="text-[10px] text-zinc-400">spots filled</div>
                    </div>
                    <button
                      onClick={() => bookClassSlot(cls.id)}
                      disabled={isFull}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 ${
                        isFull 
                          ? 'bg-zinc-200 dark:bg-zinc-800 text-zinc-400 cursor-not-allowed' 
                          : 'bg-zinc-900 dark:bg-white text-white dark:text-black hover:opacity-90 active:scale-95'
                      }`}
                    >
                      {isFull ? 'Full' : 'Book Spot'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Live Turnstile Stream */}
        <div className="glass-panel rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-zinc-700 dark:text-zinc-300" />
                <span>Live RFID Check-in Stream</span>
              </h3>
              <p className="text-[11px] text-zinc-500">
                Real-time contactless badge & QR scans
              </p>
            </div>
            <span className="text-[10px] font-mono bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 px-2 py-0.5 rounded-full border border-zinc-200 dark:border-zinc-700 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-900 dark:bg-white animate-pulse" />
              Connected
            </span>
          </div>

          <div className="space-y-2.5">
            {checkIns.map((chk) => (
              <div key={chk.id} className="flex items-center justify-between p-2.5 bg-zinc-50 dark:bg-zinc-900/40 rounded-xl border border-zinc-200 dark:border-zinc-800">
                <div className="flex items-center gap-3">
                  <img
                    src={chk.memberAvatar}
                    alt={chk.memberName}
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-zinc-300 dark:ring-zinc-700"
                  />
                  <div>
                    <div className="text-xs font-semibold text-zinc-900 dark:text-white">{chk.memberName}</div>
                    <div className="text-[10px] text-zinc-500">{chk.plan} • {chk.location}</div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded-full border border-zinc-200 dark:border-zinc-700">
                    {chk.timestamp}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
