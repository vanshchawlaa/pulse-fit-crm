export type MembershipPlan = 
  | 'All-Access VIP'
  | 'CrossFit Pro'
  | 'Standard Fitness'
  | 'Yoga & Pilates Studio'
  | 'Student / Off-Peak';

export type MembershipStatus = 'Active' | 'Expiring Soon' | 'Frozen' | 'Cancelled';

export interface Member {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar: string;
  plan: MembershipPlan;
  status: MembershipStatus;
  monthlyFee: number;
  startDate: string;
  expirationDate: string;
  totalCheckIns: number;
  lastVisit: string;
  assignedTrainer?: string;
  lockerNumber?: string;
  emergencyContact?: string;
  fitnessGoal?: string;
}

export interface ClassSession {
  id: string;
  name: string;
  category: 'HIIT' | 'Strength' | 'Yoga' | 'CrossFit' | 'Spin' | 'Boxing';
  trainerName: string;
  trainerAvatar: string;
  time: string;
  durationMinutes: number;
  room: string;
  capacity: number;
  bookedCount: number;
  intensity: 'High' | 'Medium' | 'Low';
  bookedMembers: string[];
}

export interface Trainer {
  id: string;
  name: string;
  avatar: string;
  role: string;
  specialty: string;
  activeClients: number;
  rating: number;
  sessionsCompletedThisMonth: number;
  hourlyRate: number;
  status: 'On Floor' | 'In Session' | 'Off Duty';
}

export type LeadStage = 
  | 'inquiry' 
  | 'trial_booked' 
  | 'trial_attended' 
  | 'membership_pitch' 
  | 'converted' 
  | 'lost';

export interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  interest: string;
  source: 'Instagram' | 'Walk-in' | 'Google Search' | 'Member Referral' | 'Corporate';
  stage: LeadStage;
  trialDate?: string;
  assignedStaff: string;
  notes?: string;
  createdAt: string;
}

export interface CheckInLog {
  id: string;
  memberId: string;
  memberName: string;
  memberAvatar: string;
  plan: MembershipPlan;
  timestamp: string;
  location: string;
}

export interface EquipmentItem {
  id: string;
  name: string;
  category: 'Cardio' | 'Free Weights' | 'Strength Machines' | 'Recovery & Spa';
  zone: string;
  status: 'Operational' | 'Maintenance Needed' | 'Under Repair';
  lastInspected: string;
}

// Marketing Module Types
export type CampaignChannel = 'whatsapp' | 'email';
export type CampaignAudience = 'all' | 'expiring' | 'leads' | 'vip' | 'inactive';

export interface MarketingCampaign {
  id: string;
  title: string;
  channel: CampaignChannel;
  targetAudience: CampaignAudience;
  subject?: string;
  message: string;
  sentAt: string;
  recipientCount: number;
  deliveredCount: number;
  openRate: number;
  status: 'Sent' | 'Scheduled' | 'Draft';
}

export interface MarketingTemplate {
  id: string;
  title: string;
  channel: CampaignChannel;
  category: 'Promotion' | 'Renewal' | 'Trial Pass' | 'Reminder';
  subject?: string;
  content: string;
}
