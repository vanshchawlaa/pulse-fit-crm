import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { 
  Member, 
  ClassSession, 
  Trainer, 
  Lead, 
  CheckInLog, 
  EquipmentItem, 
  LeadStage,
  MembershipPlan,
  MembershipStatus,
  MarketingCampaign,
  MarketingTemplate
} from '../types';
import { 
  INITIAL_MEMBERS, 
  INITIAL_CLASSES, 
  INITIAL_TRAINERS, 
  INITIAL_LEADS, 
  INITIAL_CHECKINS, 
  INITIAL_EQUIPMENT,
  INITIAL_CAMPAIGNS,
  INITIAL_MARKETING_TEMPLATES
} from '../data/gymMockData';

export interface CurrencyConfig {
  code: string;
  symbol: string;
  name: string;
  position: 'before' | 'after';
}

export const CURRENCIES: CurrencyConfig[] = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee', position: 'before' },
  { code: 'USD', symbol: '$', name: 'US Dollar', position: 'before' },
  { code: 'EUR', symbol: '€', name: 'Euro', position: 'before' },
  { code: 'GBP', symbol: '£', name: 'British Pound', position: 'before' },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham', position: 'before' },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', position: 'before' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', position: 'before' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar', position: 'before' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen', position: 'before' },
  { code: 'BDT', symbol: '৳', name: 'Bangladeshi Taka', position: 'before' },
  { code: 'NGN', symbol: '₦', name: 'Nigerian Naira', position: 'before' },
  { code: 'ZAR', symbol: 'R', name: 'South African Rand', position: 'before' },
];

export type ActiveView = 
  | 'overview' 
  | 'members' 
  | 'classes' 
  | 'trainers' 
  | 'leads' 
  | 'facility' 
  | 'marketing' 
  | 'import' 
  | 'analytics' 
  | 'settings'
  | 'subscriptions';

interface GymContextType {
  members: Member[];
  classes: ClassSession[];
  trainers: Trainer[];
  leads: Lead[];
  checkIns: CheckInLog[];
  equipment: EquipmentItem[];
  campaigns: MarketingCampaign[];
  templates: MarketingTemplate[];
  
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  
  currency: CurrencyConfig;
  setCurrency: (currency: CurrencyConfig) => void;
  formatPrice: (amount: number) => string;
  
  // Actions
  checkInMember: (memberId: string) => { success: boolean; message: string };
  addMember: (member: Omit<Member, 'id' | 'totalCheckIns' | 'lastVisit'>) => void;
  updateMember: (id: string, updates: Partial<Member>) => void;
  deleteMember: (id: string) => void;
  
  bookClassSlot: (classId: string, memberId?: string) => void;
  cancelClassSlot: (classId: string, memberId?: string) => void;
  
  updateLeadStage: (leadId: string, newStage: LeadStage) => void;
  addLead: (lead: Omit<Lead, 'id' | 'createdAt'>) => void;
  deleteLead: (leadId: string) => void;
  
  updateEquipmentStatus: (id: string, status: EquipmentItem['status']) => void;
  
  // Trainers CRUD
  addTrainer: (trainer: Omit<Trainer, 'id'>) => void;
  updateTrainer: (id: string, updates: Partial<Trainer>) => void;
  deleteTrainer: (id: string) => void;
  
  // Marketing
  sendCampaign: (campaign: Omit<MarketingCampaign, 'id' | 'sentAt' | 'deliveredCount' | 'openRate' | 'status'>) => void;
  
  // Import
  importMembersFromData: (imported: Partial<Member>[]) => number;
  importLeadsFromData: (imported: Partial<Lead>[]) => number;

  // Modals
  isCheckInModalOpen: boolean;
  setIsCheckInModalOpen: (open: boolean) => void;
  isNewMemberModalOpen: boolean;
  setIsNewMemberModalOpen: (open: boolean) => void;
  isImportModalOpen: boolean;
  setIsImportModalOpen: (open: boolean) => void;

  // Selected Detail Item
  selectedMember: Member | null;
  setSelectedMember: (member: Member | null) => void;

  // Metrics
  totalActiveMembers: number;
  monthlyRecurringRevenue: number;
  todaysCheckInsCount: number;
  floorCapacityPercentage: number;
  leadConversionRate: number;
}

const GymContext = createContext<GymContextType | undefined>(undefined);

export const GymProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem('gym_crm_members');
    return saved ? JSON.parse(saved) : INITIAL_MEMBERS;
  });

  const [classes, setClasses] = useState<ClassSession[]>(() => {
    const saved = localStorage.getItem('gym_crm_classes');
    return saved ? JSON.parse(saved) : INITIAL_CLASSES;
  });

  const [trainers, setTrainers] = useState<Trainer[]>(() => {
    const saved = localStorage.getItem('gym_crm_trainers');
    return saved ? JSON.parse(saved) : INITIAL_TRAINERS;
  });

  const [leads, setLeads] = useState<Lead[]>(() => {
    const saved = localStorage.getItem('gym_crm_leads');
    return saved ? JSON.parse(saved) : INITIAL_LEADS;
  });

  const [checkIns, setCheckIns] = useState<CheckInLog[]>(() => {
    const saved = localStorage.getItem('gym_crm_checkins');
    return saved ? JSON.parse(saved) : INITIAL_CHECKINS;
  });

  const [equipment, setEquipment] = useState<EquipmentItem[]>(() => {
    const saved = localStorage.getItem('gym_crm_equipment');
    return saved ? JSON.parse(saved) : INITIAL_EQUIPMENT;
  });

  const [campaigns, setCampaigns] = useState<MarketingCampaign[]>(() => {
    const saved = localStorage.getItem('gym_crm_campaigns');
    return saved ? JSON.parse(saved) : INITIAL_CAMPAIGNS;
  });

  const [templates] = useState<MarketingTemplate[]>(INITIAL_MARKETING_TEMPLATES);

  const [activeView, setActiveView] = useState<ActiveView>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('gym_crm_darkmode');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [currency, setCurrencyState] = useState<CurrencyConfig>(() => {
    const saved = localStorage.getItem('gym_crm_currency');
    if (saved) {
      const found = CURRENCIES.find(c => c.code === JSON.parse(saved));
      if (found) return found;
    }
    return CURRENCIES[0]; // Default: INR
  });

  const setCurrency = (c: CurrencyConfig) => {
    setCurrencyState(c);
    localStorage.setItem('gym_crm_currency', JSON.stringify(c.code));
  };

  const formatPrice = (amount: number): string => {
    const formatted = amount.toLocaleString();
    return currency.position === 'before'
      ? `${currency.symbol}${formatted}`
      : `${formatted}${currency.symbol}`;
  };

  const [isCheckInModalOpen, setIsCheckInModalOpen] = useState(false);
  const [isNewMemberModalOpen, setIsNewMemberModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);

  // Sync to LocalStorage
  useEffect(() => { localStorage.setItem('gym_crm_members', JSON.stringify(members)); }, [members]);
  useEffect(() => { localStorage.setItem('gym_crm_classes', JSON.stringify(classes)); }, [classes]);
  useEffect(() => { localStorage.setItem('gym_crm_trainers', JSON.stringify(trainers)); }, [trainers]);
  useEffect(() => { localStorage.setItem('gym_crm_leads', JSON.stringify(leads)); }, [leads]);
  useEffect(() => { localStorage.setItem('gym_crm_checkins', JSON.stringify(checkIns)); }, [checkIns]);
  useEffect(() => { localStorage.setItem('gym_crm_equipment', JSON.stringify(equipment)); }, [equipment]);
  useEffect(() => { localStorage.setItem('gym_crm_campaigns', JSON.stringify(campaigns)); }, [campaigns]);
  useEffect(() => { localStorage.setItem('gym_crm_darkmode', JSON.stringify(darkMode)); }, [darkMode]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Actions
  const checkInMember = (memberId: string) => {
    const mem = members.find((m) => m.id === memberId || m.phone.includes(memberId) || m.name.toLowerCase().includes(memberId.toLowerCase()));
    if (!mem) {
      return { success: false, message: 'Member not found. Check ID or Phone.' };
    }

    if (mem.status === 'Frozen' || mem.status === 'Cancelled') {
      return { success: false, message: `Access Denied: Membership is ${mem.status}.` };
    }

    const newLog: CheckInLog = {
      id: `chk-${Date.now()}`,
      memberId: mem.id,
      memberName: mem.name,
      memberAvatar: mem.avatar,
      plan: mem.plan,
      timestamp: 'Just now',
      location: 'Front Turnstile Scanner',
    };

    setCheckIns((prev) => [newLog, ...prev]);
    setMembers((prev) =>
      prev.map((m) =>
        m.id === mem.id
          ? { ...m, totalCheckIns: m.totalCheckIns + 1, lastVisit: 'Just now' }
          : m
      )
    );

    return { success: true, message: `Welcome in, ${mem.name}! Access Granted (${mem.plan})` };
  };

  const addMember = (memberData: Omit<Member, 'id' | 'totalCheckIns' | 'lastVisit'>) => {
    const newMember: Member = {
      ...memberData,
      id: `mem-${Date.now()}`,
      totalCheckIns: 1,
      lastVisit: 'Today (Joined)',
    };
    setMembers((prev) => [newMember, ...prev]);

    const newLog: CheckInLog = {
      id: `chk-${Date.now()}`,
      memberId: newMember.id,
      memberName: newMember.name,
      memberAvatar: newMember.avatar,
      plan: newMember.plan,
      timestamp: 'Just now (Welcome Check-in)',
      location: 'Member Onboarding Desk',
    };
    setCheckIns((prev) => [newLog, ...prev]);
  };

  const updateMember = (id: string, updates: Partial<Member>) => {
    setMembers((prev) => prev.map((m) => (m.id === id ? { ...m, ...updates } : m)));
    if (selectedMember && selectedMember.id === id) {
      setSelectedMember({ ...selectedMember, ...updates });
    }
  };

  const deleteMember = (id: string) => {
    setMembers((prev) => prev.filter((m) => m.id !== id));
    if (selectedMember?.id === id) {
      setSelectedMember(null);
    }
  };

  const bookClassSlot = (classId: string, memberId: string = 'mem-101') => {
    setClasses((prev) =>
      prev.map((cls) => {
        if (cls.id === classId && cls.bookedCount < cls.capacity) {
          return {
            ...cls,
            bookedCount: cls.bookedCount + 1,
            bookedMembers: [...cls.bookedMembers, memberId],
          };
        }
        return cls;
      })
    );
  };

  const cancelClassSlot = (classId: string, memberId: string = 'mem-101') => {
    setClasses((prev) =>
      prev.map((cls) => {
        if (cls.id === classId && cls.bookedCount > 0) {
          return {
            ...cls,
            bookedCount: cls.bookedCount - 1,
            bookedMembers: cls.bookedMembers.filter((m) => m !== memberId),
          };
        }
        return cls;
      })
    );
  };

  const updateLeadStage = (leadId: string, newStage: LeadStage) => {
    setLeads((prev) => prev.map((l) => (l.id === leadId ? { ...l, stage: newStage } : l)));
  };

  const addLead = (leadData: Omit<Lead, 'id' | 'createdAt'>) => {
    const newLead: Lead = {
      ...leadData,
      id: `lead-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setLeads((prev) => [newLead, ...prev]);
  };

  const deleteLead = (leadId: string) => {
    setLeads((prev) => prev.filter((l) => l.id !== leadId));
  };

  const updateEquipmentStatus = (id: string, status: EquipmentItem['status']) => {
    setEquipment((prev) => prev.map((e) => (e.id === id ? { ...e, status } : e)));
  };

  // Trainer CRUD
  const addTrainer = (trainerData: Omit<Trainer, 'id'>) => {
    const newTrainer: Trainer = {
      ...trainerData,
      id: `trn-${Date.now()}`,
    };
    setTrainers((prev) => [...prev, newTrainer]);
  };

  const updateTrainer = (id: string, updates: Partial<Trainer>) => {
    setTrainers((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
  };

  const deleteTrainer = (id: string) => {
    setTrainers((prev) => prev.filter((t) => t.id !== id));
  };

  // Marketing Campaign Dispatch
  const sendCampaign = (campaignData: Omit<MarketingCampaign, 'id' | 'sentAt' | 'deliveredCount' | 'openRate' | 'status'>) => {
    const delivered = Math.max(1, Math.round(campaignData.recipientCount * (campaignData.channel === 'whatsapp' ? 0.98 : 0.95)));
    const openRateEst = campaignData.channel === 'whatsapp' ? 92.4 : 68.5;
    
    const newCampaign: MarketingCampaign = {
      ...campaignData,
      id: `cmp-${Date.now()}`,
      sentAt: 'Just now',
      deliveredCount: delivered,
      openRate: openRateEst,
      status: 'Sent',
    };
    setCampaigns((prev) => [newCampaign, ...prev]);
  };

  // Excel / CSV Data Import
  const importMembersFromData = (importedRows: Partial<Member>[]): number => {
    const validMembers: Member[] = importedRows
      .filter((r) => r.name && r.name.trim().length > 0)
      .map((r, idx) => ({
        id: r.id || `mem-imp-${Date.now()}-${idx}`,
        name: r.name!.trim(),
        email: r.email || `${r.name!.toLowerCase().replace(/\s+/g, '')}@gymmember.com`,
        phone: r.phone || '+1 (555) 000-0000',
        avatar: r.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        plan: (r.plan as MembershipPlan) || 'Standard Fitness',
        status: (r.status as MembershipStatus) || 'Active',
        monthlyFee: r.monthlyFee || (r.plan === 'All-Access VIP' ? 179 : r.plan === 'CrossFit Pro' ? 149 : 79),
        startDate: r.startDate || new Date().toISOString().split('T')[0],
        expirationDate: r.expirationDate || new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        totalCheckIns: r.totalCheckIns || 0,
        lastVisit: r.lastVisit || 'Not yet visited',
        assignedTrainer: r.assignedTrainer || 'Alex Rivera',
        lockerNumber: r.lockerNumber || undefined,
        fitnessGoal: r.fitnessGoal || 'General Fitness',
        emergencyContact: r.emergencyContact || undefined,
      }));

    if (validMembers.length > 0) {
      setMembers((prev) => [...validMembers, ...prev]);
    }
    return validMembers.length;
  };

  const importLeadsFromData = (importedRows: Partial<Lead>[]): number => {
    const validLeads: Lead[] = importedRows
      .filter((r) => r.name && r.name.trim().length > 0)
      .map((r, idx) => ({
        id: r.id || `lead-imp-${Date.now()}-${idx}`,
        name: r.name!.trim(),
        phone: r.phone || '+1 (555) 000-0000',
        email: r.email || `${r.name!.toLowerCase().replace(/\s+/g, '')}@leadguest.com`,
        interest: r.interest || 'All-Access VIP',
        source: (r.source as Lead['source']) || 'Walk-in',
        stage: (r.stage as LeadStage) || 'inquiry',
        trialDate: r.trialDate || undefined,
        assignedStaff: r.assignedStaff || 'Alex Rivera',
        notes: r.notes || 'Imported via Excel Batch',
        createdAt: new Date().toISOString().split('T')[0],
      }));

    if (validLeads.length > 0) {
      setLeads((prev) => [...validLeads, ...prev]);
    }
    return validLeads.length;
  };

  // Aggregations
  const totalActiveMembers = useMemo(() => {
    return members.filter((m) => m.status === 'Active' || m.status === 'Expiring Soon').length;
  }, [members]);

  const monthlyRecurringRevenue = useMemo(() => {
    return members
      .filter((m) => m.status === 'Active' || m.status === 'Expiring Soon')
      .reduce((sum, m) => sum + m.monthlyFee, 0);
  }, [members]);

  const todaysCheckInsCount = useMemo(() => {
    return checkIns.length;
  }, [checkIns]);

  const floorCapacityPercentage = useMemo(() => {
    const maxCapacity = 140;
    const currentOnFloor = Math.min(maxCapacity, Math.round(checkIns.length * 0.65));
    return Math.round((currentOnFloor / maxCapacity) * 100);
  }, [checkIns]);

  const leadConversionRate = useMemo(() => {
    const totalLeads = leads.length;
    if (totalLeads === 0) return 24;
    const converted = leads.filter((l) => l.stage === 'converted').length;
    return Math.round((converted / totalLeads) * 100) || 28;
  }, [leads]);

  return (
    <GymContext.Provider
      value={{
        members,
        classes,
        trainers,
        leads,
        checkIns,
        equipment,
        campaigns,
        templates,
        activeView,
        setActiveView,
        searchQuery,
        setSearchQuery,
        darkMode,
        setDarkMode,
        currency,
        setCurrency,
        formatPrice,
        checkInMember,
        addMember,
        updateMember,
        deleteMember,
        bookClassSlot,
        cancelClassSlot,
        updateLeadStage,
        addLead,
        deleteLead,
        updateEquipmentStatus,
        addTrainer,
        updateTrainer,
        deleteTrainer,
        sendCampaign,
        importMembersFromData,
        importLeadsFromData,
        isCheckInModalOpen,
        setIsCheckInModalOpen,
        isNewMemberModalOpen,
        setIsNewMemberModalOpen,
        isImportModalOpen,
        setIsImportModalOpen,
        selectedMember,
        setSelectedMember,
        totalActiveMembers,
        monthlyRecurringRevenue,
        todaysCheckInsCount,
        floorCapacityPercentage,
        leadConversionRate,
      }}
    >
      {children}
    </GymContext.Provider>
  );
};

export const useGym = () => {
  const context = useContext(GymContext);
  if (!context) {
    throw new Error('useGym must be used within a GymProvider');
  }
  return context;
};
