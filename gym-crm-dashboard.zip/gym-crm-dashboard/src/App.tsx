import React from 'react';
import { GymProvider, useGym } from './context/GymContext';
import { GymSidebar } from './components/GymSidebar';
import { GymHeader } from './components/GymHeader';
import { GymOverview } from './components/GymOverview';
import { MembersView } from './components/MembersView';
import { ClassesScheduleView } from './components/ClassesScheduleView';
import { TrainersView } from './components/TrainersView';
import { LeadsPipelineView } from './components/LeadsPipelineView';
import { FacilityEquipmentView } from './components/FacilityEquipmentView';
import { MarketingHubView } from './components/MarketingHubView';
import { DataImportView } from './components/DataImportView';
import { SubscriptionPlansView } from './components/SubscriptionPlansView';
import { CheckInModal } from './components/CheckInModal';
import { NewMemberModal } from './components/NewMemberModal';
import { MemberDetailDrawer } from './components/MemberDetailDrawer';

const GymAppContent: React.FC = () => {
  const { activeView } = useGym();

  const getHeaderInfo = () => {
    switch (activeView) {
      case 'overview':
        return { title: 'Operations & Floor Command', subtitle: 'Live capacity, daily workouts, revenue pacing & retention radar' };
      case 'members':
        return { title: 'Members Directory & Contracts', subtitle: 'Searchable member database, RFID tags, locker assignments & tiers' };
      case 'marketing':
        return { title: 'WhatsApp & Email Marketing Hub', subtitle: 'Broadcast retention promotions, renewal discounts & trial guest passes' };
      case 'import':
        return { title: 'Excel & CSV Data Ingestion', subtitle: 'Batch import client rosters, leads, and member spreadsheets directly' };
      case 'classes':
        return { title: 'Group Fitness & Timetable', subtitle: 'Studio capacity, reservations, coach assignments & intensity levels' };
      case 'subscriptions':
        return { title: 'Subscription Plan Builder', subtitle: 'Create and manage gym membership tiers and pricing' };
      case 'trainers':
        return { title: 'Coaches & Personal Trainers', subtitle: 'Active client rosters, commission rates & floor availability' };
      case 'leads':
        return { title: 'Guest Trials & Sales Funnel', subtitle: 'Convert walk-ins and social inquiries into long-term members' };
      case 'facility':
        return { title: 'Equipment Health & Facility Uptime', subtitle: 'Uptime monitoring for cardio decks, power racks & plunge suites' };
      case 'analytics':
        return { title: 'Revenue & Retention Analytics', subtitle: 'MRR breakdown, member lifetime value & peak hour heatmaps' };
      case 'settings':
        return { title: 'Club Infrastructure & Hardware', subtitle: 'Turnstile gates, RFID scanner integration, Stripe billing' };
      default:
        return { title: 'Club Operations', subtitle: '' };
    }
  };

  const headerInfo = getHeaderInfo();

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-white dark:bg-black text-zinc-900 dark:text-zinc-100 gym-ambient-mesh transition-colors duration-200">
      {/* Sidebar */}
      <GymSidebar />

      {/* Main Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <GymHeader title={headerInfo.title} subtitle={headerInfo.subtitle} />

        <main className="flex-1 overflow-y-auto relative z-0">
          {activeView === 'overview' && <GymOverview />}
          {activeView === 'members' && <MembersView />}
          {activeView === 'marketing' && <MarketingHubView />}
          {activeView === 'import' && <DataImportView />}
          {activeView === 'classes' && <ClassesScheduleView />}
          {activeView === 'trainers' && <TrainersView />}
          {activeView === 'subscriptions' && <SubscriptionPlansView />}
          {activeView === 'leads' && <LeadsPipelineView />}
          {activeView === 'facility' && <FacilityEquipmentView />}
          {activeView === 'analytics' && <GymOverview />}
          {activeView === 'settings' && (
            <div className="p-8 max-w-3xl mx-auto space-y-6 animate-fade-in">
              <div className="glass-panel rounded-2xl p-6 shadow-sm">
                <h3 className="text-sm font-semibold text-zinc-900 dark:text-white mb-1.5">Hardware & RFID Gateway</h3>
                <p className="text-xs text-zinc-500 mb-5">
                  Turnstile barrier scanner, optical POS terminal, and digital locker controller link.
                </p>
                <div className="space-y-3 text-xs">
                  <div className="flex justify-between py-2.5 border-b border-zinc-200 dark:border-zinc-800">
                    <span className="text-zinc-500">Turnstile Scanner Gateway</span>
                    <span className="font-mono text-zinc-900 dark:text-white font-medium">Online (Gate A / B)</span>
                  </div>
                  <div className="flex justify-between py-2.5 border-b border-zinc-200 dark:border-zinc-800">
                    <span className="text-zinc-500">Contactless Member RFID Frequency</span>
                    <span className="font-mono text-zinc-700 dark:text-zinc-300">13.56 MHz (Mifare Plus)</span>
                  </div>
                  <div className="flex justify-between py-2.5 border-b border-zinc-200 dark:border-zinc-800">
                    <span className="text-zinc-500">Stripe Billing Auto-Renew</span>
                    <span className="text-zinc-900 dark:text-white font-medium">Synchronized</span>
                  </div>
                  <div className="flex justify-between py-2.5 border-b border-zinc-200 dark:border-zinc-800">
                    <span className="text-zinc-500">Offline Cache & Instant Persistence</span>
                    <span className="text-zinc-900 dark:text-white font-medium">Local Storage Armed</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Modals & Drawers */}
      <CheckInModal />
      <NewMemberModal />
      <MemberDetailDrawer />
    </div>
  );
};

export default function App() {
  return (
    <GymProvider>
      <GymAppContent />
    </GymProvider>
  );
}
