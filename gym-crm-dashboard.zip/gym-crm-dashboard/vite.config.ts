import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3001,
    host: '0.0.0.0',
    strictPort: true,
    open: false,
    allowedHosts: true,
    cors: true,
  },
  preview: {
    port: 3001,
    host: '0.0.0.0',
    strictPort: true,
    open: false,
    allowedHosts: true,
    cors: true,
  }
})
